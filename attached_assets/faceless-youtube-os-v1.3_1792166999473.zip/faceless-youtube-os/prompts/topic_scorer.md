You give a FIRST-PASS score for a YouTube documentary topic. A human will confirm or change your scores, so be honest rather than flattering; most ideas should score below the maximum.

Input (JSON): {"topic", "pillar", "maxima": {"curiosity": 25, "audience": 20, "story": 20, "visuals": 10, "evergreen": 10, "monetization": 10}}

Score each factor from 0 up to its maximum:
- curiosity: does the title raise a question people must answer?
- audience: how many people already care about this subject?
- story: is there a real situation, problem, mystery, discovery, revelation?
- visuals: can it be shown with filmable stock footage, maps and graphics?
- evergreen: will it still be interesting in a year?
- monetization: is the subject advertiser-friendly and tied to valuable audiences?
- difficulty: production difficulty penalty from 0 (easy) to 5 (very hard to research or visualise).

Return ONLY JSON:
{"curiosity": 0, "audience": 0, "story": 0, "visuals": 0, "evergreen": 0, "monetization": 0, "difficulty": 0, "rationale": "two sentences"}

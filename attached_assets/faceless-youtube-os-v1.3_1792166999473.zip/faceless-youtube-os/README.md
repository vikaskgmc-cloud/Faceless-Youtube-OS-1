# Faceless YouTube OS

A human-in-the-loop production line for faceless documentary videos
("the world behind the headlines"). It automates the repetitive work (research,
drafting, voice, footage, rough cut, packaging checks, analytics reading) and
**stops for a human decision at every important gate.** It never publishes.

Built from the ChatGPT plan you shared: status pipeline, claims database,
100-point topic score, story arc, "automate repetition, not judgment", manual
upload first, decision tree for analytics, secrets only in environment variables.

## The line

```
IDEA -> SELECTED -> RESEARCHING -> RESEARCH_COMPLETE -> SCRIPTING -> SCRIPT_REVIEW
 -> APPROVED -> VOICE -> VISUALS -> EDITING -> QA -> THUMBNAIL -> UPLOAD_READY
 -> PUBLISHED -> ANALYZING
```

| Gate (you decide) | Command | What the code enforces |
|---|---|---|
| Topic | `select` | Score confirmed by you and >= 75, or you give an override reason |
| Research | `approve-research` | At least 5 verified claims; editing any claim withdraws the approval |
| Script | `approve-script` | Fact-check re-run at the gate; any blocking problem stops it |
| Title + thumbnail | `approve-thumbnail` | No unsupported figures; thumbnail has 1-4 words |
| Publish | `published --url` | You upload manually, then record it. Nothing here talks to YouTube |

A project can only move to the next status; skipping ahead raises an error.

## Quick start

```bash
cp .env.example .env        # fill in keys, or set them as Replit Secrets
python -m faceless_os new "Why <country> has millions of empty houses" --pillar countries
python -m faceless_os score 001 --suggest        # AI first pass; review it
python -m faceless_os score 001 --confirm        # or enter your own: --curiosity 22 --audience 16 ...
python -m faceless_os select 001                 # GATE 1
python -m faceless_os research 001               # live search; or: --sources pages.json
python -m faceless_os claims 001                 # read every claim and its quote
python -m faceless_os claim 001 C007 --status rejected --note "page does not say this"
python -m faceless_os approve-research 001       # GATE 2
python -m faceless_os script 001                 # story script + automatic fact-check
python -m faceless_os export-script 001          # edit script.json by hand if you like
python -m faceless_os import-script 001 data/projects/001-.../script.json
python -m faceless_os approve-script 001         # GATE 3
python -m faceless_os voice 001 --dry-run        # shows the chunk plan, costs nothing
python -m faceless_os voice 001
python -m faceless_os visuals 001
python -m faceless_os assemble 001
python -m faceless_os qa 001
python -m faceless_os titles 001
python -m faceless_os approve-thumbnail 001 --title curiosity     # GATE 4
python -m faceless_os ready 001                  # writes upload_package.md
# upload the video yourself, then:
python -m faceless_os published 001 --url https://youtube.com/watch?v=...
python -m faceless_os analyze 001 --ctr 5.2 --retention 41 --curve retention.csv
```

Needs Python 3.10+ and, for voice/visuals/assembly, `ffmpeg` and `ffprobe`.
No third-party Python packages. Run the tests with
`python -m unittest discover -s tests -t .`

## Automation and 4K

`autopilot` runs every machine step up to the next human gate, then tells you what to decide:

```bash
python -m faceless_os autopilot 001 --quality 4k   # research | script | voice | footage | 3840x2160 cut | QA | titles
```

It never selects, approves, edits claims or publishes. Typical rhythm: `select` -> `autopilot` ->
review claims, `approve-research` -> `autopilot` -> review script, `approve-script` -> `autopilot` ->
review the cut, `approve-thumbnail`, `ready`, upload yourself.

`--quality 4k` picks 2560-3840 px Pexels files and renders 3840x2160. Where a clip only exists in lower
resolution it is upscaled and QA warns how many. 4K rendering is slow and large (a 10-minute cut can take
a long time and several GB), so do it on a machine with CPU and disk to spare, not a free Replit plan.
The cut gets a finishing pass: a slow drift on every shot with soft dips at the cuts, `captions.srt`
(upload it to YouTube, or add `--burn-captions`), loudness normalised to -14 LUFS, optional royalty-free
music that ducks under the voice (`--music file.mp3`; you must hold the licence), and `+faststart`.
Captions are timed by word share, not forced-aligned, so check them.

**Not built yet, and what separates this from a studio edit:** animated maps and charts, stat cards,
real motion graphics, an AI-generated or designed thumbnail image, sound effects, colour grading, and a
human editor's eye. Stock footage alone will not make a channel stand out. Original angles, accurate
research and a recognisable voice and format will.

## Series and the return loop

A faceless channel has no face, so the repeat-viewing habit has to come from the format: the same calm
narrator, the same opening and closing, and every video pointing at the next one.

```bash
python -m faceless_os new "Why <country> has millions of empty houses" --series "Quiet Giants"
python -m faceless_os next-idea 001 "The city that paid people to stay"   # what the last line will tease
```

The script writer then writes the episode as part of a recurring show and ends by teasing exactly the
story you named. You choose the next idea; the tool only makes sure the loop exists.

## How the research agent avoids made-up facts

1. It plans 8-12 research questions, searches, and is shown the **text of the pages it found**.
2. It must cite a source **by index** (so it cannot invent a URL) and give an **exact quote**.
3. **Code, not the model, decides "verified":** the quote must appear verbatim in the page
   text, every number in the claim must be in the quote, and meaning-changing words
   (doubled/tripled, million/billion, most/all...) must be in the quote too.
4. Two verified claims about the same metric with different figures are both marked `conflicting`.
5. The script writer sees **only verified claims**, tags each scene with claim ids, and the
   fact-check blocks any figure that is not in a cited verified claim.

## Settings (environment variables or Replit Secrets)

See `.env.example`. Keys are read only from the environment, never saved in project
files and never printed. Prompts live in `prompts/*.md`; edit them to tune the agents.

## Known limits (read these)

- **Live services were not tested.** The Anthropic/OpenAI, Firecrawl, ElevenLabs and Pexels
  calls follow those services' documented HTTP APIs but have never been run with real keys.
  Everything else is tested offline with fakes (64 tests, including a real ffmpeg render).
  Expect to fix small things on the first live run. Firecrawl and Pexels response shapes are the most likely.
- **Verification proves a quote exists, not that a paraphrase means the same.** It catches
  fabricated quotes, changed numbers and swapped key words. It cannot catch every subtle
  re-wording, which is why you approve the research yourself. Read the quotes.
- The fact-check only requires sources for figures of 10+ or with decimals, and does not
  check numbers written as words ("nine million"). Review the script for those.
- The topic score formula tops out at **95**, not 100 (25+20+20+10+10+10, minus 0-5). The 75 threshold is from the plan.
- Length estimate assumes ~150 words per minute. YouTube has no ideal length; this is just info.
- Pexels footage is generic stock, so scenes can look repetitive. The rough cut is for review, not final.
- Only English text-to-speech has been considered; ElevenLabs model/voice are your choice.
- Nothing here checks YouTube's rules on repetitive or mass-produced content. The plan's advice
  applies: make each video genuinely original, with your own angle and review.

## Layout

```
faceless_os/   models, workflow (gates), storage, research, story, factcheck, titles,
               voice, visuals, assemble, analytics, pipeline, cli
prompts/       researcher_*, scriptwriter, title_generator, topic_scorer
tests/         unit + end-to-end tests with fictional "Examplia" facts
data/projects/ one folder per video (git-ignored)
```

## Later (V2, from the plan)

Topic discovery agent, YouTube analytics API import, auto-upload as a *draft* with your
approval, Shorts cut from the same research, a dashboard (your Replit app can read `data/projects/*/project.json`).

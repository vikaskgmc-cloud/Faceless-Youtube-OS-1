"""The pipeline: each method is one step of the production line, with its gate.

Providers (LLM, search, voice, footage) are injected, so the whole line can be run
offline with fakes in tests and with real services in production.
Nothing here uploads or publishes anything: a human does that, then records it.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from . import analytics, assemble, factcheck, media, research, scoring, story, titles, visuals, voice
from .llm import LLM
from .models import CLAIM_STATUSES, Project, Scene, now_iso
from .search import SearchProvider
from .storage import ProjectStore
from .workflow import GateError, advance, approve, require_status, revoke


class Pipeline:
    def __init__(
        self,
        store: ProjectStore,
        *,
        llm: LLM | None = None,
        search: SearchProvider | None = None,
        tts: voice.TTS | None = None,
        video_search: visuals.VideoSearch | None = None,
    ):
        self.store = store
        self.llm = llm
        self.search = search
        self.tts = tts
        self.video_search = video_search

    # ---- helpers ---------------------------------------------------------
    @staticmethod
    def _need(obj: Any, what: str) -> Any:
        if obj is None:
            raise GateError(f"No {what} is configured for this step.")
        return obj

    def _folder(self, p: Project) -> Path:
        return self.store.dir(p.id)

    def _save(self, p: Project) -> Project:
        self.store.save(p)
        return p

    # ---- 1. idea & topic -------------------------------------------------
    def new_project(self, topic: str, pillar: str = "", title: str = "", series: str = "") -> Project:
        if not topic.strip():
            raise GateError("A project needs a topic.")
        p = Project(id=self.store.new_id(topic), topic=topic.strip(), pillar=pillar.strip(), title=title.strip(), series=series.strip())
        return self._save(p)

    def set_next_idea(self, ref: str, idea: str) -> Project:
        """The story the closing line will tease: the next-video loop, decided by a human."""
        p = self.store.load(ref)
        p.next_idea = idea.strip()
        return self._save(p)

    def set_score(self, ref: str, components: dict[str, float]) -> Project:
        p = self.store.load(ref)
        require_status(p, ("IDEA",), "score a topic")
        p.score = {**scoring.compute(components), "confirmed": True, "suggested_by": "human"}
        return self._save(p)

    def suggest_score(self, ref: str) -> Project:
        p = self.store.load(ref)
        require_status(p, ("IDEA",), "score a topic")
        p.score = {**scoring.suggest(p, self._need(self.llm, "LLM")), "confirmed": False}
        return self._save(p)

    def confirm_score(self, ref: str) -> Project:
        p = self.store.load(ref)
        if not p.score:
            raise GateError("Nothing to confirm: score the topic first.")
        p.score["confirmed"] = True
        return self._save(p)

    def select(self, ref: str, override_reason: str = "") -> Project:
        """Human approval of the topic."""
        p = self.store.load(ref)
        require_status(p, ("IDEA",), "select a topic")
        if not p.score:
            raise GateError("Score the topic first.")
        if not p.score.get("confirmed"):
            raise GateError("The score is only an AI suggestion. Confirm it (or enter your own scores) first.")
        if not p.score["passes"] and not override_reason.strip():
            raise GateError(
                f"Score {p.score['total']} is below the {p.score['threshold']} needed for production. "
                "Pick a stronger idea, or pass --override with your reason."
            )
        note = f"score {p.score['total']}" + (f"; override: {override_reason.strip()}" if override_reason.strip() else "")
        approve(p, "topic", note=note)
        advance(p, "SELECTED", note)
        return self._save(p)

    # ---- 2. research -----------------------------------------------------
    def run_research(self, ref: str, results_per_question: int = 4) -> Project:
        p = self.store.load(ref)
        require_status(p, ("SELECTED", "RESEARCHING", "RESEARCH_COMPLETE"), "run research")
        if p.status == "SELECTED":
            advance(p, "RESEARCHING")
            self._save(p)
        research.run_research(
            p, self._need(self.llm, "LLM"), self._need(self.search, "search provider"), results_per_question=results_per_question
        )
        if p.status == "RESEARCHING":
            advance(p, "RESEARCH_COMPLETE")
        else:
            revoke(p, "research")  # a re-run invalidates earlier approval
        return self._save(p)

    def set_claim(self, ref: str, claim_id: str, status: str, note: str) -> Project:
        p = self.store.load(ref)
        require_status(p, ("RESEARCH_COMPLETE",), "edit claims")
        if status not in CLAIM_STATUSES:
            raise GateError(f"Status must be one of: {', '.join(CLAIM_STATUSES)}.")
        if status == "verified" and not note.strip():
            raise GateError("Marking a claim verified by hand needs a note saying how you checked it.")
        claims = p.claims()
        target = next((c for c in claims if c.id == claim_id), None)
        if target is None:
            raise GateError(f"No claim {claim_id}.")
        target.status = status
        target.note = note.strip()
        target.verified_by = "human" if status == "verified" else ""
        p.set_claims(claims)
        revoke(p, "research")  # evidence changed: approval must be given again
        return self._save(p)

    def approve_research(self, ref: str) -> Project:
        p = self.store.load(ref)
        require_status(p, ("RESEARCH_COMPLETE",), "approve research")
        n = len(p.verified_claims())
        if n < story.MIN_VERIFIED_CLAIMS:
            raise GateError(f"Only {n} verified claims; at least {story.MIN_VERIFIED_CLAIMS} are needed before scripting.")
        approve(p, "research", note=f"{n} verified claims")
        return self._save(p)

    # ---- 3. script -------------------------------------------------------
    def _store_revision(self, p: Project, scenes: list[Scene], note: str) -> dict[str, Any]:
        p.set_scenes(scenes)
        report = factcheck.check_script(scenes, p.claims())
        p.script["factcheck"] = report
        p.script["revisions"].append(
            {"rev": len(p.script["revisions"]) + 1, "at": now_iso(), "note": note, "factcheck_ok": report["ok"], "scenes": [s.__dict__ for s in scenes]}
        )
        return report

    def write_script(self, ref: str, min_claims: int = story.MIN_VERIFIED_CLAIMS) -> Project:
        p = self.store.load(ref)
        require_status(p, ("RESEARCH_COMPLETE", "SCRIPTING", "SCRIPT_REVIEW"), "write a script")
        if "research" not in p.approvals:
            raise GateError("Research must be approved by a human before scripting.")
        if p.status == "RESEARCH_COMPLETE":
            advance(p, "SCRIPTING")
            self._save(p)
        scenes = story.generate_script(p, self._need(self.llm, "LLM"), min_claims=min_claims)
        self._store_revision(p, scenes, "generated by the story agent")
        if p.status == "SCRIPTING":
            advance(p, "SCRIPT_REVIEW")
        return self._save(p)

    def import_script(self, ref: str, path: str | Path) -> Project:
        """Replace the scenes with a human-edited JSON file (same shape as export-script)."""
        p = self.store.load(ref)
        require_status(p, ("SCRIPT_REVIEW",), "import an edited script")
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        items = raw["scenes"] if isinstance(raw, dict) else raw
        scenes = [
            Scene(
                id=f"S{i + 1:02d}",
                section=str(s["section"]),
                narration=str(s["narration"]).strip(),
                visual_query=str(s.get("visual_query", "")),
                claim_ids=[str(c) for c in s.get("claim_ids", [])],
            )
            for i, s in enumerate(items)
        ]
        self._store_revision(p, scenes, "edited by a human")
        return self._save(p)

    def export_script(self, ref: str) -> tuple[Path, Path]:
        p = self.store.load(ref)
        scenes = p.scenes()
        if not scenes:
            raise GateError("There is no script yet.")
        folder = self._folder(p)
        js = folder / "script.json"
        md = folder / "script.md"
        js.write_text(json.dumps({"scenes": [s.__dict__ for s in scenes]}, indent=2, ensure_ascii=False), encoding="utf-8")
        md.write_text(f"# {p.title or p.topic}\n\n" + story.script_text(scenes), encoding="utf-8")
        return js, md

    def run_factcheck(self, ref: str) -> dict[str, Any]:
        p = self.store.load(ref)
        require_status(p, ("SCRIPT_REVIEW",), "fact-check")
        report = factcheck.check_script(p.scenes(), p.claims())
        p.script["factcheck"] = report
        self._save(p)
        return report

    def approve_script(self, ref: str) -> Project:
        p = self.store.load(ref)
        require_status(p, ("SCRIPT_REVIEW",), "approve the script")
        report = factcheck.check_script(p.scenes(), p.claims())  # always re-checked at the gate
        p.script["factcheck"] = report
        if not report["ok"]:
            problems = "; ".join(f"{b['scene']}: {b['message']}" for b in report["blocking"][:3])
            self._save(p)
            raise GateError(f"The script has blocking problems and cannot be approved. {problems}")
        approve(p, "script", note=f"{report['stats']['words']} words, {len(report['warnings'])} warnings")
        advance(p, "APPROVED")
        return self._save(p)

    # ---- 4. voice, visuals, edit -----------------------------------------
    def make_voice(self, ref: str, dry_run: bool = False, max_chars: int = voice.DEFAULT_MAX_CHARS) -> dict[str, Any]:
        p = self.store.load(ref)
        require_status(p, ("APPROVED", "VOICE"), "generate the voice")
        text = story.narration_text(p.scenes())
        if dry_run:
            chunks = voice.chunk_text(text, max_chars)
            return {"dry_run": True, "characters": len(text), "chunks": [len(c) for c in chunks]}
        tts = self._need(self.tts, "voice service")
        if p.status == "APPROVED":
            advance(p, "VOICE")
            self._save(p)
        result = voice.narrate(text, self._folder(p) / "audio", tts, max_chars=max_chars)
        p.assets["audio"] = result
        self._save(p)
        return result

    def find_visuals(self, ref: str, dry_run: bool = False, per_scene: int = 3, quality: str = "hd") -> dict[str, Any]:
        p = self.store.load(ref)
        require_status(p, ("VOICE", "VISUALS"), "collect visuals")
        if "audio" not in p.assets:
            raise GateError("Generate the voice first.")
        scenes = p.scenes()
        if dry_run:
            return {"dry_run": True, "queries": {s.id: s.visual_query for s in scenes}}
        search = self._need(self.video_search, "footage provider")
        selection = visuals.find_clips(scenes, search, per_scene=per_scene, quality=quality)
        folder = self._folder(p)
        visuals.download_clips(selection, folder / "clips")
        credits = folder / "credits.md"
        visuals.write_credits(selection, credits)
        p.assets["visuals"] = {"scenes": selection, "credits_file": str(credits), "quality": quality}
        if p.status == "VOICE":
            advance(p, "VISUALS")
        self._save(p)
        return {"scenes_with_footage": sum(1 for c in selection.values() if c), "scenes": len(selection), "credits_file": str(credits)}

    def assemble(self, ref: str, size: tuple[int, int] = (1920, 1080), music: str | Path | None = None, burn_captions: bool = False) -> dict[str, Any]:
        p = self.store.load(ref)
        require_status(p, ("VISUALS", "EDITING"), "assemble the rough cut")
        audio = p.assets.get("audio", {})
        if not audio.get("file") or not Path(audio["file"]).is_file():
            raise GateError("The narration file is missing; generate the voice first.")
        total = audio.get("duration") or media.duration(audio["file"])
        clips = p.assets.get("visuals", {}).get("scenes", {})
        timeline = assemble.build_timeline(p.scenes(), float(total), clips)
        folder = self._folder(p)
        if music and not Path(music).is_file():
            raise GateError(f"Music file not found: {music}. Use royalty-free music you have the licence for.")
        cues = assemble.build_captions(p.scenes(), timeline)
        srt = assemble.write_srt(cues, folder / "video" / "captions.srt") if cues else None
        result = assemble.render(
            timeline, Path(audio["file"]), folder / "video" / "rough_cut.mp4", folder / "video" / "work",
            size=size, music=Path(music) if music else None, captions=srt, burn_captions=burn_captions,
        )
        p.assets["video"] = {**result, "timeline": timeline, "captions_file": str(srt) if srt else ""}
        if p.status == "VISUALS":
            advance(p, "EDITING")
        self._save(p)
        return result

    # ---- 5. QA, packaging, hand-off ---------------------------------------
    def qa(self, ref: str) -> dict[str, Any]:
        p = self.store.load(ref)
        require_status(p, ("EDITING", "QA"), "run QA")
        checks: list[dict[str, Any]] = []

        def add(name: str, ok: bool, level: str = "required") -> None:
            checks.append({"name": name, "ok": bool(ok), "level": level})

        audio = p.assets.get("audio", {})
        video = p.assets.get("video", {})
        add("narration audio exists", audio.get("file") and Path(audio["file"]).is_file())
        add("rough cut exists", video.get("file") and Path(video["file"]).is_file())
        if audio.get("duration") and video.get("duration"):
            add("video and narration lengths match (within 1.5 s)", abs(audio["duration"] - video["duration"]) <= 1.5)
        selection = p.assets.get("visuals", {}).get("scenes", {})
        missing = [sid for sid, clips in selection.items() if not clips]
        add("every scene has footage" + (f" (missing: {', '.join(missing)})" if missing else ""), not missing, "advisory")
        target_w = (p.assets.get("video", {}).get("size", "0x0")).split("x")[0]
        if target_w.isdigit() and int(target_w) >= 3840:
            clips = [c for cs in selection.values() for c in cs]
            soft = [c for c in clips if (c.get("width") or 0) < 2560]
            add(f"4K cut: {len(soft)} of {len(clips)} clips are below 2560 px wide and are upscaled", not soft, "advisory")
        add("footage credits file exists", Path(p.assets.get("visuals", {}).get("credits_file", "")).is_file())
        add("script approval on record", "script" in p.approvals)
        add("script still passes the fact-check", factcheck.check_script(p.scenes(), p.claims())["ok"])
        passed = all(c["ok"] for c in checks if c["level"] == "required")
        if passed and p.status == "EDITING":
            advance(p, "QA")
            self._save(p)
        return {"passed": passed, "checks": checks}

    def make_titles(self, ref: str) -> dict[str, Any]:
        p = self.store.load(ref)
        if p.status not in ("APPROVED", "VOICE", "VISUALS", "EDITING", "QA", "THUMBNAIL"):
            raise GateError("Titles are generated once the script is approved.")
        package = titles.generate_titles(p, self._need(self.llm, "LLM"))
        p.titles = {**p.titles, **package}
        self._save(p)
        return package

    def approve_thumbnail(self, ref: str, choice: str, words: str = "") -> Project:
        """Human approval of title + thumbnail. `choice` is a title family name or your own title text."""
        p = self.store.load(ref)
        require_status(p, ("QA",), "approve the title and thumbnail")
        generated = p.titles.get("titles", {})
        title = generated.get(choice, "") if choice in titles.FAMILIES else choice.strip()
        thumb_words = (words or p.titles.get("thumbnail", {}).get("words", "")).strip().upper()
        allowed: set[str] = set()
        for c in p.verified_claims():
            allowed |= research.numbers_in(c.claim)
        issues = titles.check_title(title, allowed) + titles.check_thumbnail_words(thumb_words)
        blocking = [i["message"] for i in issues if i["level"] == "blocking"]
        if blocking:
            raise GateError("Cannot approve: " + " ".join(blocking))
        p.title = title
        p.titles["approved"] = {"title": title, "thumbnail_words": thumb_words, "visual": p.titles.get("thumbnail", {}).get("visual", "")}
        approve(p, "thumbnail", note=title)
        advance(p, "THUMBNAIL")
        return self._save(p)

    def ready(self, ref: str) -> Path:
        p = self.store.load(ref)
        require_status(p, ("THUMBNAIL",), "mark upload-ready")
        advance(p, "UPLOAD_READY")
        used = set(p.script.get("factcheck", {}).get("stats", {}).get("claims_used", []))
        sources: dict[str, str] = {}
        for c in p.claims():
            if c.id in used:
                sources.setdefault(c.source_url, c.source_title or c.source_url)
        approved = p.titles.get("approved", {})
        lines = [
            f"# Upload package: {p.title}",
            "",
            "Upload this yourself. Nothing in this tool publishes to YouTube.",
            "",
            f"- Video file: {p.assets.get('video', {}).get('file', '(missing)')}",
            f"- Title: {p.title}",
            f"- Thumbnail words: {approved.get('thumbnail_words', '')}",
            f"- Thumbnail image idea: {approved.get('visual', '')}",
            "",
            "## Description draft",
            "",
            p.research.get("summary", {}).get("angle", ""),
            "",
            "Sources:",
            *[f"- {t}: {u}" for u, t in sources.items()],
            "",
            "Video footage provided by Pexels (https://www.pexels.com). Credits: see credits.md.",
            "",
        ]
        path = self._folder(p) / "upload_package.md"
        path.write_text("\n".join(lines), encoding="utf-8")
        self._save(p)
        return path

    def mark_published(self, ref: str, url: str) -> Project:
        """A human records that THEY uploaded the video."""
        p = self.store.load(ref)
        require_status(p, ("UPLOAD_READY",), "record publication")
        if not url.strip().startswith(("http://", "https://")):
            raise GateError("Give the public URL of the video you uploaded.")
        p.publish = {"url": url.strip(), "recorded_at": now_iso(), "by": "human"}
        advance(p, "PUBLISHED", "recorded by a human")
        return self._save(p)

    # ---- 6. analytics ----------------------------------------------------
    def channel_history(self, exclude: str = "") -> list[dict[str, float]]:
        history = []
        for other in self.store.list():
            if other.id != exclude and other.analytics:
                latest = other.analytics[-1]
                history.append({"ctr": latest["ctr"], "retention": latest["retention"]})
        return history

    def record_analytics(self, ref: str, ctr: float, retention: float, curve: str | Path | None = None) -> dict[str, Any]:
        p = self.store.load(ref)
        require_status(p, ("PUBLISHED", "ANALYZING"), "record analytics")
        baseline = analytics.baseline_from(self.channel_history(exclude=p.id))
        result: dict[str, Any] = {"diagnosis": analytics.diagnose(ctr, retention, baseline), "baseline": baseline}
        if curve:
            points = analytics.parse_curve(curve)
            result["retention"] = analytics.retention_insights(points, p.assets.get("video", {}).get("timeline", []))
        p.analytics.append({"at": now_iso(), "ctr": ctr, "retention": retention, **{k: v for k, v in result.items() if k != "baseline"}})
        if p.status == "PUBLISHED":
            advance(p, "ANALYZING")
        self._save(p)
        return result

    # ---- automation: run every step that needs no human decision --------------
    def autopilot(self, ref: str, quality: str = "hd", size: tuple[int, int] = (1920, 1080), music: str | None = None) -> list[str]:
        """Run the machine steps from the current status until the next human gate.
        It never approves, selects, edits claims or publishes; it stops and says what you must decide."""
        done: list[str] = []
        p = self.store.load(ref)
        if p.status == "SELECTED":
            self.run_research(ref); done.append("research")
        p = self.store.load(ref)
        if p.status == "RESEARCH_COMPLETE" and "research" in p.approvals:
            self.write_script(ref); done.append("script + fact-check")
        p = self.store.load(ref)
        if p.status == "APPROVED":
            self.make_voice(ref); done.append("voice")
            p = self.store.load(ref)
        if p.status == "VOICE":
            self.find_visuals(ref, quality=quality); done.append(f"footage ({quality})")
            p = self.store.load(ref)
        if p.status == "VISUALS":
            self.assemble(ref, size=size, music=music); done.append(f"rough cut {size[0]}x{size[1]}")
            p = self.store.load(ref)
        if p.status in ("EDITING", "QA"):
            report = self.qa(ref); done.append("QA " + ("passed" if report["passed"] else "NOT passed"))
            p = self.store.load(ref)
            if report["passed"] and not p.titles.get("titles"):
                self.make_titles(ref); done.append("titles + thumbnail concept")
        return done

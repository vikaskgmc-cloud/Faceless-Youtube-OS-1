"""Title families and thumbnail concept, with mechanical checks.

Plan rules: five title families (curiosity, mystery, contrarian, scale, question);
thumbnail = one object + one emotion + 1-4 words; title and thumbnail must agree
and must not promise what the video cannot deliver.
"""
from __future__ import annotations

import json
from typing import Any

from .factcheck import _significant_numbers
from .llm import LLM
from .models import Project
from .prompts import load_prompt
from .research import numbers_in

FAMILIES = ("curiosity", "mystery", "contrarian", "scale", "question")
TITLE_SOFT_LIMIT = 70  # characters; longer titles risk truncation in feeds (house rule, not a YouTube rule)
THUMB_MAX_WORDS = 4


def check_title(title: str, verified_numbers: set[str]) -> list[dict[str, str]]:
    issues: list[dict[str, str]] = []
    if not title.strip():
        return [{"level": "blocking", "message": "Title is empty."}]
    if len(title) > TITLE_SOFT_LIMIT:
        issues.append({"level": "warning", "message": f"{len(title)} characters; may be cut off (aim for {TITLE_SOFT_LIMIT} or fewer)."})
    letters = [c for c in title if c.isalpha()]
    if letters and sum(c.isupper() for c in letters) / len(letters) > 0.6:
        issues.append({"level": "warning", "message": "Mostly capital letters; reads as shouting."})
    loose = _significant_numbers(title) - verified_numbers
    if loose:
        issues.append({"level": "blocking", "message": f"Title uses figures that no verified claim supports: {', '.join(sorted(loose))}."})
    return issues


def check_thumbnail_words(words: str) -> list[dict[str, str]]:
    n = len(words.split())
    if n == 0:
        return [{"level": "blocking", "message": "Thumbnail has no words."}]
    if n > THUMB_MAX_WORDS:
        return [{"level": "blocking", "message": f"Thumbnail has {n} words; the rule is 1 to {THUMB_MAX_WORDS}."}]
    return []


def generate_titles(project: Project, llm: LLM) -> dict[str, Any]:
    verified = project.verified_claims()
    scenes = project.scenes()
    hook = next((s.narration for s in scenes if s.section == "hook"), "")
    data = llm.complete_json(
        load_prompt("title_generator"),
        json.dumps(
            {
                "topic": project.topic,
                "angle": project.research.get("summary", {}).get("angle", ""),
                "hook": hook,
                "verified_claims": [{"id": c.id, "claim": c.claim} for c in verified],
                "families": list(FAMILIES),
            },
            ensure_ascii=False,
        ),
        task="titles",
    )
    raw_titles = data.get("titles", {}) if isinstance(data, dict) else {}
    thumb = data.get("thumbnail", {}) if isinstance(data, dict) else {}
    titles = {f: str(raw_titles.get(f, "")).strip() for f in FAMILIES}
    allowed = set().union(*(numbers_in(c.claim) for c in verified)) if verified else set()
    thumbnail = {
        "words": str(thumb.get("words", "")).strip().upper(),
        "visual": str(thumb.get("visual", "")).strip(),
        "emotion": str(thumb.get("emotion", "")).strip(),
    }
    return {
        "titles": titles,
        "thumbnail": thumbnail,
        "issues": {
            **{f: check_title(t, allowed) for f, t in titles.items()},
            "thumbnail": check_thumbnail_words(thumbnail["words"]),
        },
    }

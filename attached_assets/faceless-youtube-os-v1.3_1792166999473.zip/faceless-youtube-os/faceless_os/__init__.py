"""Faceless YouTube OS: a human-in-the-loop production pipeline for faceless documentary videos."""

__version__ = "1.0.0"

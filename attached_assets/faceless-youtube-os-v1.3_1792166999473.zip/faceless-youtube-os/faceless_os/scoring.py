"""Topic scoring: the 100-point formula from the ChatGPT plan.

Curiosity 25, audience size 20, story potential 20, visual potential 10,
evergreen potential 10, monetisation 10, minus production difficulty (0-5).
Note the best possible total is therefore 95, not 100; the plan's own example
(23+19+19+9+8+9-3) gives 84, and only ideas of 75 or more enter production.
A human always confirms the scores; an LLM suggestion is only a starting point.
"""
from __future__ import annotations

import json
from typing import Any

from .llm import LLM
from .models import Project
from .prompts import load_prompt

MAXIMA = {
    "curiosity": 25,
    "audience": 20,
    "story": 20,
    "visuals": 10,
    "evergreen": 10,
    "monetization": 10,
}
DIFFICULTY_MAX = 5
THRESHOLD = 75


class ScoreError(ValueError):
    pass


def compute(components: dict[str, float], threshold: int = THRESHOLD) -> dict[str, Any]:
    clean: dict[str, float] = {}
    for name, top in MAXIMA.items():
        if name not in components:
            raise ScoreError(f"Missing score for {name}.")
        value = float(components[name])
        if not 0 <= value <= top:
            raise ScoreError(f"{name} must be between 0 and {top}, got {value:g}.")
        clean[name] = value
    difficulty = abs(float(components.get("difficulty", 0)))  # the plan writes it as -3; accept 3 or -3
    if difficulty > DIFFICULTY_MAX:
        raise ScoreError(f"difficulty penalty must be between 0 and {DIFFICULTY_MAX}.")
    clean["difficulty"] = difficulty
    total = sum(clean[n] for n in MAXIMA) - difficulty
    return {
        "components": clean,
        "total": round(total, 1),
        "max_possible": sum(MAXIMA.values()),
        "threshold": threshold,
        "passes": total >= threshold,
    }


def suggest(project: Project, llm: LLM) -> dict[str, Any]:
    """Ask the LLM for first-pass scores. Marked as a suggestion; a human confirms."""
    data = llm.complete_json(
        load_prompt("topic_scorer"),
        json.dumps({"topic": project.topic, "pillar": project.pillar, "maxima": MAXIMA}),
        task="score_topic",
    )
    result = compute({**{k: data.get(k, 0) for k in MAXIMA}, "difficulty": data.get("difficulty", 0)})
    result["suggested_by"] = "llm"
    result["rationale"] = str(data.get("rationale", ""))[:600]
    return result

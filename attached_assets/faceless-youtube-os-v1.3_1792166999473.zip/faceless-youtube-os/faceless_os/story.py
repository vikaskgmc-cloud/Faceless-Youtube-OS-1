"""Story-first script generation, limited to verified claims.

The arc follows the ChatGPT plan: hook -> promise -> setup -> discovery ->
escalation -> big reveal -> consequence -> next curiosity. Each scene lists the
claim ids it relies on, so the fact-checker can audit every statement.
"""
from __future__ import annotations

import json
from typing import Any

from .llm import LLM
from .models import Project, Scene
from .prompts import load_prompt

SECTIONS = [
    ("hook", "About 20 seconds. The most unexpected concrete fact. End on an open question."),
    ("promise", "State the mystery this video will solve."),
    ("setup", "Only the context needed to follow the story."),
    ("discovery", "The first real revelation. Finish by opening a new question."),
    ("escalation", "It gets bigger or stranger: a complication, a cost, an obstacle."),
    ("big_reveal", "The answer the title promised."),
    ("consequence", "Why this matters beyond this one story."),
    ("next_curiosity", "One closing line that makes the viewer curious about the next video. Never beg for subscribes."),
]
SECTION_NAMES = [name for name, _ in SECTIONS]
MIN_VERIFIED_CLAIMS = 5


class ScriptError(RuntimeError):
    pass


def generate_script(project: Project, llm: LLM, min_claims: int = MIN_VERIFIED_CLAIMS) -> list[Scene]:
    verified = project.verified_claims()
    if len(verified) < min_claims:
        raise ScriptError(
            f"Only {len(verified)} verified claims; at least {min_claims} are needed to write a script "
            "that is not padded. Research more, or verify claims by hand."
        )
    summary = project.research.get("summary", {})
    payload: dict[str, Any] = {
        "title": project.title or project.topic,
        "topic": project.topic,
        "series": project.series,
        "next_video": project.next_idea,
        "angle": summary.get("angle", ""),
        "sections": [{"name": n, "purpose": p} for n, p in SECTIONS],
        "verified_claims": [{"id": c.id, "claim": c.claim} for c in verified],
    }
    data = llm.complete_json(
        load_prompt("scriptwriter"), json.dumps(payload, ensure_ascii=False), task="write_script", max_tokens=8000
    )
    raw = data.get("scenes") if isinstance(data, dict) else None
    if not isinstance(raw, list) or not raw:
        raise ScriptError("The model returned no scenes.")

    parsed = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        section = str(item.get("section", "")).strip()
        narration = str(item.get("narration", "")).strip()
        if section not in SECTION_NAMES or not narration:
            continue
        ids = item.get("claim_ids", [])
        parsed.append(
            (
                SECTION_NAMES.index(section),
                section,
                narration,
                str(item.get("visual_query", "")).strip(),
                [str(i) for i in ids] if isinstance(ids, list) else [],
            )
        )
    if not parsed:
        raise ScriptError("No usable scenes (each needs a known section and narration).")
    parsed.sort(key=lambda t: t[0])  # stable: keeps the model's order within a section
    return [Scene(id=f"S{i + 1:02d}", section=s, narration=n, visual_query=v, claim_ids=c) for i, (_, s, n, v, c) in enumerate(parsed)]


def script_text(scenes: list[Scene]) -> str:
    """Readable script with section headings (for review, not for the voice)."""
    lines: list[str] = []
    current = ""
    for s in scenes:
        if s.section != current:
            current = s.section
            lines.append(f"## {current.replace('_', ' ').upper()}")
        lines.append(s.narration)
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def narration_text(scenes: list[Scene]) -> str:
    """Only the words that will be spoken."""
    return "\n\n".join(s.narration.strip() for s in scenes)

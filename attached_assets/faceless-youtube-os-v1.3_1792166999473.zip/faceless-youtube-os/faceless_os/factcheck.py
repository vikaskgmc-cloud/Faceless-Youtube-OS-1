"""Deterministic fact-check of a script against the claims database.

Blocking problems stop approval. Warnings are for the human to judge.
It cannot prove a script is *true*; it proves every statement is traceable to a
verified, sourced claim, and that no figure appeared out of nowhere.
"""
from __future__ import annotations

import re
from typing import Any

from .models import Claim, Scene
from .research import numbers_in

WORDS_PER_MINUTE = 150  # narration pace assumption used for the length estimate
HOOK_MAX_WORDS = 55  # roughly 20 seconds
FACTUAL_SECTIONS = {"hook", "setup", "discovery", "escalation", "big_reveal", "consequence"}
REQUIRED_SECTIONS = ("hook", "big_reveal", "next_curiosity")
SUSPENSE_PHRASES = (
    "but there's a problem",
    "but there was a problem",
    "what happened next",
    "you won't believe",
    "nobody expected",
    "here's where things get crazy",
    "but that's not all",
    "and then everything changed",
)


def _significant_numbers(text: str) -> set[str]:
    """Figures that need a source: decimals and whole numbers of 10 or more.
    Single digits ("3 reasons") are ignored; numbers written as words are not checked."""
    out = set()
    for n in numbers_in(text):
        if "." in n or int(n) >= 10:
            out.add(n)
    return out


def check_script(scenes: list[Scene], claims: list[Claim]) -> dict[str, Any]:
    by_id = {c.id: c for c in claims}
    blocking: list[dict[str, str]] = []
    warnings: list[dict[str, str]] = []

    def block(scene: str, code: str, message: str) -> None:
        blocking.append({"scene": scene, "code": code, "message": message})

    def warn(scene: str, code: str, message: str) -> None:
        warnings.append({"scene": scene, "code": code, "message": message})

    if not scenes:
        block("-", "empty", "The script has no scenes.")

    used: set[str] = set()
    for s in scenes:
        cited_numbers: set[str] = set()
        for cid in s.claim_ids:
            claim = by_id.get(cid)
            if claim is None:
                block(s.id, "unknown_claim", f"Cites {cid}, which is not in the claims database.")
            elif claim.status != "verified":
                block(s.id, "unverified_claim", f"Cites {cid}, which is {claim.status}, not verified.")
            else:
                used.add(cid)
                cited_numbers |= numbers_in(claim.claim)
        loose = _significant_numbers(s.narration) - cited_numbers
        if loose:
            block(s.id, "unsupported_number", f"Figures not found in the cited claims: {', '.join(sorted(loose))}.")
        if s.section in FACTUAL_SECTIONS and not s.claim_ids:
            warn(s.id, "untagged_scene", f"'{s.section}' scene cites no claim; check it contains no hidden facts.")

    present = {s.section for s in scenes}
    for section in REQUIRED_SECTIONS:
        if scenes and section not in present:
            warn("-", "missing_section", f"No '{section}' section.")

    for s in scenes:
        if s.section == "hook" and len(s.narration.split()) > HOOK_MAX_WORDS:
            warn(s.id, "long_hook", f"Hook is {len(s.narration.split())} words; aim for about {HOOK_MAX_WORDS} (20 seconds).")
        if s.section == "next_curiosity" and re.search(r"\bsubscribe\b|\bsmash\b|\bhit the bell\b", s.narration, re.I):
            warn(s.id, "subscribe_begging", "End with curiosity about the next story, not a plea to subscribe.")

    text = " ".join(s.narration for s in scenes).lower()
    words = len(text.split())
    suspense = sum(text.count(p) for p in SUSPENSE_PHRASES)
    if words and suspense > words / 250 + 1:
        warn("-", "suspense_overuse", f"{suspense} stock suspense phrases in {words} words; viewers notice manufactured suspense.")

    verified_ids = {c.id for c in claims if c.status == "verified"}
    return {
        "ok": not blocking,
        "blocking": blocking,
        "warnings": warnings,
        "stats": {
            "scenes": len(scenes),
            "words": words,
            "est_minutes": round(words / WORDS_PER_MINUTE, 1),
            "claims_used": sorted(used),
            "verified_claims_unused": sorted(verified_ids - used),
        },
    }

"""JSON-file storage: one folder per project, project.json inside."""
from __future__ import annotations

import json
import os
from pathlib import Path

from .models import Project, now_iso, slugify


class StoreError(Exception):
    pass


class ProjectStore:
    def __init__(self, root: str | os.PathLike[str]):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def dir(self, project_id: str) -> Path:
        return self.root / project_id

    def new_id(self, topic: str) -> str:
        n = 1
        existing = {p.name for p in self.root.iterdir() if p.is_dir()}
        while True:
            pid = f"{n:03d}-{slugify(topic)}"
            if pid not in existing and not any(e.startswith(f"{n:03d}-") for e in existing):
                return pid
            n += 1

    def resolve(self, ref: str) -> str:
        """Accept a full id or a unique prefix such as '001'."""
        if (self.root / ref / "project.json").is_file():
            return ref
        matches = sorted(
            p.name for p in self.root.iterdir() if p.is_dir() and p.name.startswith(ref) and (p / "project.json").is_file()
        )
        if len(matches) == 1:
            return matches[0]
        if not matches:
            raise StoreError(f"No project matches {ref!r}.")
        raise StoreError(f"{ref!r} is ambiguous: {', '.join(matches)}")

    def save(self, project: Project) -> None:
        project.updated = now_iso()
        folder = self.dir(project.id)
        folder.mkdir(parents=True, exist_ok=True)
        tmp = folder / "project.json.tmp"
        tmp.write_text(json.dumps(project.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, folder / "project.json")

    def load(self, ref: str) -> Project:
        pid = self.resolve(ref)
        data = json.loads((self.dir(pid) / "project.json").read_text(encoding="utf-8"))
        return Project.from_dict(data)

    def list(self) -> list[Project]:
        out = []
        for p in sorted(self.root.iterdir()):
            if (p / "project.json").is_file():
                out.append(self.load(p.name))
        return out

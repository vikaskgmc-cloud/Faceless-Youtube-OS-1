"""Tiny HTTP helper built on the standard library (no third-party dependencies)."""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


class HttpError(RuntimeError):
    def __init__(self, status: int, body: str, url: str):
        self.status = status
        # keep only the host + a short body; never request headers (they hold API keys)
        host = url.split("/")[2] if "//" in url else url
        super().__init__(f"HTTP {status} from {host}: {body[:300]}")


def request(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    payload: Any = None,
    timeout: float = 120,
    retries: int = 2,
) -> bytes:
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    hdrs = {"User-Agent": "faceless-youtube-os/1.0", **(headers or {})}
    if data is not None:
        hdrs.setdefault("Content-Type", "application/json")
    last: HttpError | None = None
    for attempt in range(retries + 1):
        req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read()
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace")
            last = HttpError(exc.code, body, url)
            if exc.code not in (429, 500, 502, 503, 504) or attempt == retries:
                raise last from None
        except urllib.error.URLError as exc:
            last = HttpError(0, str(exc.reason), url)
            if attempt == retries:
                raise last from None
        time.sleep(1.5 * (attempt + 1))
    raise last  # pragma: no cover


def get_json(url: str, **kw: Any) -> Any:
    return json.loads(request(url, **kw).decode("utf-8"))


def post_json(url: str, payload: Any, **kw: Any) -> Any:
    return json.loads(request(url, method="POST", payload=payload, **kw).decode("utf-8"))


def download(url: str, dest: Path, timeout: float = 300) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "faceless-youtube-os/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp, open(tmp, "wb") as fh:
            while True:
                block = resp.read(1 << 20)
                if not block:
                    break
                fh.write(block)
    except urllib.error.HTTPError as exc:
        raise HttpError(exc.code, exc.read().decode("utf-8", "replace"), url) from None
    except urllib.error.URLError as exc:
        raise HttpError(0, str(exc.reason), url) from None
    tmp.replace(dest)
    return dest

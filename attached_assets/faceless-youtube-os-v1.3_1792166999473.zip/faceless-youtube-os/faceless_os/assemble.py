"""Rough-cut assembly with ffmpeg: narration + footage -> a first cut to review.

Per the plan, footage changes every 2-6 seconds (visual progression, not frantic
editing). The goal is a usable first cut for a human to review, not a finished edit.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Any

from . import media
from .models import Scene

CARD_COLOUR = "0x0b1530"  # dark navy placeholder when a scene has no footage


def scene_durations(scenes: list[Scene], total: float) -> dict[str, float]:
    """Share the narration length between scenes in proportion to their word counts."""
    words = {s.id: max(1, len(s.narration.split())) for s in scenes}
    whole = sum(words.values())
    return {sid: total * w / whole for sid, w in words.items()}


def plan_shots(duration: float, min_shot: float = 2.0, max_shot: float = 6.0, target: float = 4.0) -> list[float]:
    if duration <= 0:
        return []
    if duration < min_shot:
        return [duration]
    n = max(1, round(duration / target))
    shot = duration / n
    if shot > max_shot:
        n = math.ceil(duration / max_shot)
    elif shot < min_shot:
        n = max(1, math.floor(duration / min_shot))
    return [duration / n] * n


def build_timeline(scenes: list[Scene], total: float, clips: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    durations = scene_durations(scenes, total)
    timeline: list[dict[str, Any]] = []
    clock = 0.0
    for scene in scenes:
        dur = durations[scene.id]
        usable = [c for c in clips.get(scene.id, []) if c.get("file")]
        shots = []
        offsets: dict[str, float] = {}
        for i, shot_len in enumerate(plan_shots(dur)):
            clip = usable[i % len(usable)] if usable else None
            offset = 0.0
            if clip:
                key = clip["file"]
                offset = offsets.get(key, 0.0)
                clip_len = float(clip.get("duration") or 0) or 0.0
                nxt = offset + shot_len
                offsets[key] = nxt % clip_len if clip_len > shot_len else 0.0
            shots.append({"clip": clip["file"] if clip else None, "duration": round(shot_len, 3), "offset": round(offset, 3)})
        timeline.append(
            {"scene": scene.id, "section": scene.section, "start": round(clock, 3), "end": round(clock + dur, 3), "shots": shots}
        )
        clock += dur
    return timeline


def _srt_time(t: float) -> str:
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    sec, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"


def build_captions(scenes: list[Scene], timeline: list[dict[str, Any]], max_words: int = 9) -> list[tuple[float, float, str]]:
    """Caption cues timed by word share inside each scene. Estimated, not forced-aligned:
    good enough for a review cut; replace with a real aligner for final captions."""
    by_id = {e["scene"]: e for e in timeline}
    cues: list[tuple[float, float, str]] = []
    for sc in scenes:
        entry = by_id.get(sc.id)
        words = sc.narration.split()
        if not entry or not words:
            continue
        groups = [words[i:i + max_words] for i in range(0, len(words), max_words)]
        span = entry["end"] - entry["start"]
        clock = entry["start"]
        for g in groups:
            dur = span * len(g) / len(words)
            cues.append((round(clock, 3), round(clock + dur, 3), " ".join(g)))
            clock += dur
    return cues


def write_srt(cues: list[tuple[float, float, str]], path: Path) -> Path:
    lines = []
    for i, (a, b, text) in enumerate(cues, 1):
        lines += [str(i), f"{_srt_time(a)} --> {_srt_time(b)}", text, ""]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _shot_filter(w: int, h: int, duration: float) -> str:
    """Slight over-scale, then a slow left-to-right drift (never a static frame), with soft dips at the cut."""
    sw, sh = int(w * 1.06) // 2 * 2, int(h * 1.06) // 2 * 2
    fade = min(0.15, duration / 4)
    return (
        f"scale={sw}:{sh}:force_original_aspect_ratio=increase,"
        f"crop={w}:{h}:x='(iw-{w})*t/{max(duration, 0.1):.3f}':y='(ih-{h})/2',setsar=1,"
        f"fade=t=in:st=0:d={fade:.3f},fade=t=out:st={max(duration - fade, 0):.3f}:d={fade:.3f}"
    )


def render(
    timeline: list[dict[str, Any]],
    narration: Path,
    out_file: Path,
    work_dir: Path,
    *,
    size: tuple[int, int] = (1920, 1080),
    fps: int = 30,
    music: Path | None = None,
    captions: Path | None = None,
    burn_captions: bool = False,
    crf: int = 18,
) -> dict[str, Any]:
    if not media.have_ffmpeg():
        raise media.MediaError("ffmpeg is not installed, so the rough cut cannot be rendered.")
    w, h = size
    work_dir.mkdir(parents=True, exist_ok=True)
    encode = ["-an", "-r", str(fps), "-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p"]
    shot_files: list[Path] = []
    n = 0
    for entry in timeline:
        for shot in entry["shots"]:
            n += 1
            out = work_dir / f"shot_{n:04d}.mp4"
            d = shot["duration"]
            if shot["clip"]:
                cmd = ["ffmpeg", "-y", "-loglevel", "error", "-stream_loop", "-1", "-ss", f"{shot['offset']:.3f}", "-i", shot["clip"], "-t", f"{d:.3f}", "-vf", _shot_filter(w, h, d), *encode, str(out)]
            else:
                cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"color=c={CARD_COLOUR}:s={w}x{h}:r={fps}", "-t", f"{d:.3f}", *encode, str(out)]
            media.run(cmd)
            shot_files.append(out)
    listing = work_dir / "shots.txt"
    listing.write_text("".join(f"file '{f.resolve()}'\n" for f in shot_files), encoding="utf-8")
    silent = work_dir / "silent.mp4"
    media.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(listing), "-c", "copy", str(silent)])

    out_file.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", str(silent), "-i", str(narration)]
    if music:
        cmd += ["-stream_loop", "-1", "-i", str(music)]  # all inputs first, then output options
    video_codec = ["-c:v", "copy"]
    if burn_captions:
        if not captions or not media.has_filter("subtitles"):
            raise media.MediaError("Burned-in captions need a captions file and an ffmpeg built with libass.")
        escaped = str(captions).replace("\\", "/").replace(":", "\\:")
        fs = max(18, h // 24)
        cmd += ["-vf", f"subtitles='{escaped}':force_style='Fontsize={fs},Outline=2,MarginV={h // 18}'"]
        video_codec = ["-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p"]
    loud = "loudnorm=I=-14:TP=-1.5:LRA=11"
    if music:
        cmd += ["-filter_complex", f"[1:a]asplit[v][sc];[2:a]volume=0.35[m];[m][sc]sidechaincompress=threshold=0.04:ratio=10:attack=20:release=400[duck];[v][duck]amix=inputs=2:duration=first:normalize=0,{loud}[aout]", "-map", "0:v", "-map", "[aout]"]
    else:
        cmd += ["-af", loud, "-map", "0:v", "-map", "1:a"]
    cmd += [*video_codec, "-c:a", "aac", "-b:a", "256k", "-shortest", "-movflags", "+faststart", str(out_file)]
    media.run(cmd)
    return {
        "file": str(out_file), "shots": len(shot_files), "duration": round(media.duration(out_file), 2), "size": f"{w}x{h}",
        "music": bool(music), "burned_captions": burn_captions, "loudness_target": "-14 LUFS",
    }

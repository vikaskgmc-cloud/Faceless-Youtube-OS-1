"""Source gathering. The research agent may only cite pages that came through here.

Firecrawl does live search + page reading. `ManualSources` lets you feed pages you
collected yourself (a JSON file), which also works fully offline.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from . import config
from .http import post_json


class SearchError(RuntimeError):
    pass


@dataclass
class SearchResult:
    url: str
    title: str
    content: str  # page text (markdown) that was actually read
    date: str = ""


class SearchProvider(Protocol):
    def search(self, query: str, limit: int = 4) -> list[SearchResult]: ...


class Firecrawl:
    URL = "https://api.firecrawl.dev/v1/search"

    def search(self, query: str, limit: int = 4) -> list[SearchResult]:
        data = post_json(
            self.URL,
            {"query": query, "limit": limit, "scrapeOptions": {"formats": ["markdown"]}},
            headers={"Authorization": f"Bearer {config.require('FIRECRAWL_API_KEY')}"},
            timeout=180,
        )
        if not data.get("success", True):
            raise SearchError("Firecrawl reported a failed search.")
        out = []
        for item in data.get("data", []):
            content = item.get("markdown") or ""
            url = item.get("url") or ""
            if url and content.strip():  # only pages whose text we really have
                meta = item.get("metadata") or {}
                out.append(
                    SearchResult(
                        url=url,
                        title=item.get("title") or meta.get("title") or "",
                        content=content,
                        date=str(meta.get("publishedTime") or meta.get("modifiedTime") or "")[:10],
                    )
                )
        return out


class ManualSources:
    """Pages you gathered yourself: a JSON list of {url, title, content, date}."""

    def __init__(self, path: str | Path):
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        self.pages = [
            SearchResult(p["url"], p.get("title", ""), p["content"], p.get("date", "")) for p in raw
        ]

    def search(self, query: str, limit: int = 4) -> list[SearchResult]:
        words = {w for w in query.lower().split() if len(w) > 3}
        scored = sorted(
            self.pages,
            key=lambda p: -sum(1 for w in words if w in (p.title + " " + p.content).lower()),
        )
        return scored[:limit]

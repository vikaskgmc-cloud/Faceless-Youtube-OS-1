"""Research agent.

topic -> research questions -> pages actually read -> claims with a verbatim quote
-> code verifies each quote against the page text -> conflicts flagged -> summary.

The model never decides what is "verified". It must point at a source it was shown
(by index, so it cannot invent URLs) and quote the page; code then checks that the
quote really appears in the page text and that every number in the claim appears in
that quote. Anything else stays `needs_checking` and cannot reach the script.
"""
from __future__ import annotations

import json
import re
from typing import Any

from .llm import LLM
from .models import Claim, Project, now_iso
from .prompts import load_prompt
from .search import SearchProvider, SearchResult

MAX_PAGE_CHARS = 6000  # how much of each page the model is shown
MIN_QUOTE_CHARS = 20


class ResearchError(RuntimeError):
    pass


_NUM = re.compile(r"\d[\d,]*(?:\.\d+)?")
_PUNCT = str.maketrans(
    {"‘": "'", "’": "'", "“": '"', "”": '"', "–": "-", "—": "-", " ": " "}
)


def numbers_in(text: str) -> set[str]:
    return {m.replace(",", "") for m in _NUM.findall(text)}


def normalize(text: str) -> str:
    t = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", text)  # markdown links -> their text
    t = t.translate(_PUNCT).lower()
    t = re.sub(r"[*_`#>\[\]()]", "", t)
    return re.sub(r"\s+", " ", t).strip()


# Words that change a claim's meaning when a paraphrase swaps them ("doubled" -> "tripled",
# "million" -> "billion", "most" -> "all"). If the claim uses one, the quote must too.
RISKY_WORDS = frozenset(
    "doubled tripled quadrupled halved increased decreased rose fell grew dropped surged plunged "
    "most majority all every none never always only first last largest biggest smallest highest lowest "
    "record thousand million billion trillion percent".split()
)


def _words(text: str) -> set[str]:
    return set(re.findall(r"[a-z]+", normalize(text)))


def verify_claim(claim_text: str, quote: str, page_text: str) -> tuple[str, str, str]:
    """Return (status, verified_by, note).

    Checks (all must pass): the quote is long enough, it appears in the page text,
    every number in the claim is in the quote, and any meaning-changing word in the
    claim (direction, quantity, unit) is also in the quote. It cannot judge a
    paraphrase's overall meaning; that is what the human research approval is for."""
    if len(quote.strip()) < MIN_QUOTE_CHARS:
        return "needs_checking", "", "quote missing or too short to prove the claim"
    if normalize(quote) not in normalize(page_text):
        return "needs_checking", "", "quote not found in the page text"
    extra = numbers_in(claim_text) - numbers_in(quote)
    if extra:
        return "needs_checking", "", f"claim contains numbers not in the quote: {', '.join(sorted(extra))}"
    drift = (_words(claim_text) & RISKY_WORDS) - _words(quote)
    if drift:
        return "needs_checking", "", f"claim uses words the quote does not: {', '.join(sorted(drift))}"
    return "verified", "quote-match", ""


def plan_questions(llm: LLM, topic: str, pillar: str) -> list[str]:
    data = llm.complete_json(
        load_prompt("researcher_questions"),
        json.dumps({"topic": topic, "pillar": pillar}),
        task="plan_questions",
    )
    raw = data.get("questions", []) if isinstance(data, dict) else data
    questions = [q.strip() for q in raw if isinstance(q, str) and q.strip()]
    if len(questions) < 3:
        raise ResearchError("The model produced too few research questions.")
    return questions[:12]


def extract_claims(llm: LLM, question: str, results: list[SearchResult]) -> list[dict[str, Any]]:
    sources = [
        {"index": i + 1, "title": r.title, "url": r.url, "date": r.date, "text": r.content[:MAX_PAGE_CHARS]}
        for i, r in enumerate(results)
    ]
    data = llm.complete_json(
        load_prompt("researcher_extract"),
        json.dumps({"question": question, "sources": sources}, ensure_ascii=False),
        task="extract_claims",
    )
    claims = data.get("claims", []) if isinstance(data, dict) else []
    return [c for c in claims if isinstance(c, dict)]


def mark_conflicts(claims: list[Claim]) -> None:
    """Two verified claims about the same metric with different numbers -> both 'conflicting'."""
    groups: dict[str, list[Claim]] = {}
    for c in claims:
        if c.status == "verified" and c.metric:
            groups.setdefault(c.metric, []).append(c)
    for metric, group in groups.items():
        signatures = {frozenset(n) for c in group if (n := numbers_in(c.claim))}
        if len(signatures) > 1:
            for c in group:
                c.status = "conflicting"
                c.verified_by = ""
                c.note = f"Sources disagree on '{metric}'. Decide which is right before scripting."


def summarise(llm: LLM, project: Project, claims: list[Claim]) -> dict[str, Any]:
    verified = [c for c in claims if c.status == "verified"]
    summary: dict[str, Any] = {
        "angle": "",
        "surprising": [],
        "open_questions": [],
        "title_ideas": [],
        "unverified_claim_ids": [c.id for c in claims if c.status != "verified"],
        "draft": True,  # an agent draft; the human approves research separately
    }
    if not verified:
        summary["open_questions"] = ["No claim could be verified from the pages found."]
        return summary
    data = llm.complete_json(
        load_prompt("researcher_summary"),
        json.dumps(
            {"topic": project.topic, "verified_claims": [{"id": c.id, "claim": c.claim} for c in verified]},
            ensure_ascii=False,
        ),
        task="summarise_research",
    )
    if isinstance(data, dict):
        summary["angle"] = str(data.get("angle", ""))
        for key in ("surprising", "open_questions", "title_ideas"):
            value = data.get(key, [])
            summary[key] = [str(v) for v in value][:8] if isinstance(value, list) else []
    return summary


def run_research(
    project: Project,
    llm: LLM,
    search: SearchProvider,
    *,
    today: str | None = None,
    results_per_question: int = 4,
) -> None:
    today = today or now_iso()[:10]
    questions = plan_questions(llm, project.topic, project.pillar)
    claims: list[Claim] = []
    sources: dict[str, dict[str, str]] = {}
    errors: list[dict[str, str]] = []

    for question in questions:
        try:
            results = search.search(question, results_per_question)
        except Exception as exc:  # one failed search must not kill the run
            errors.append({"question": question, "error": str(exc)[:200]})
            continue
        if not results:
            errors.append({"question": question, "error": "no readable pages found"})
            continue
        for r in results:
            sources.setdefault(r.url, {"url": r.url, "title": r.title, "date": r.date, "fetched_on": today})
        try:
            raw = extract_claims(llm, question, results)
        except Exception as exc:
            errors.append({"question": question, "error": f"claim extraction failed: {str(exc)[:160]}"})
            continue
        for item in raw:
            idx = item.get("source_index")
            if not isinstance(idx, int) or not 1 <= idx <= len(results):
                continue  # pointed at a source it was never shown: dropped
            page = results[idx - 1]
            text = str(item.get("claim", "")).strip()
            quote = str(item.get("quote", "")).strip()
            if not text:
                continue
            status, by, note = verify_claim(text, quote, page.content)
            confidence = str(item.get("confidence", "low")).lower()
            claims.append(
                Claim(
                    id=f"C{len(claims) + 1:03d}",
                    claim=text,
                    source_url=page.url,
                    source_title=page.title,
                    quote=quote,
                    date=str(item.get("date") or page.date or ""),
                    checked_on=today,
                    confidence=confidence if confidence in ("high", "medium", "low") else "low",
                    status=status,
                    verified_by=by,
                    metric=str(item.get("metric") or "").strip().lower(),
                    question=question,
                    note=note,
                )
            )

    if not claims:
        raise ResearchError(
            "No claims could be extracted. Check your search key, or supply pages with --sources. "
            f"Errors: {errors[:3]}"
        )
    mark_conflicts(claims)
    project.set_claims(claims)
    project.research.update(
        questions=questions,
        sources=list(sources.values()),
        errors=errors,
        ran_at=now_iso(),
        summary=summarise(llm, project, claims),
    )

"""Settings come only from environment variables (or a local, git-ignored .env).

API keys are never written to project files, logs or error messages.
"""
from __future__ import annotations

import os
from pathlib import Path


class MissingSecret(RuntimeError):
    pass


def load_dotenv(path: str = ".env") -> None:
    p = Path(path)
    if not p.is_file():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def require(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise MissingSecret(
            f"{name} is not set. Put it in your environment (Replit Secrets, or a local .env file "
            "that is git-ignored). Never paste it into chat or commit it."
        )
    return value


def optional(name: str, default: str = "") -> str:
    return os.environ.get(name, "").strip() or default

"""LLM access behind one small interface, so the brain can be swapped.

Providers: Anthropic and OpenAI (plain HTTPS, no SDK needed). Keys are read from
environment variables only. `task` is a label used for logging and by test fakes.
"""
from __future__ import annotations

import json
from typing import Any, Protocol

from . import config
from .http import post_json


class LLMError(RuntimeError):
    pass


class LLM(Protocol):
    def complete(self, system: str, prompt: str, *, task: str = "", max_tokens: int = 4096) -> str: ...

    def complete_json(self, system: str, prompt: str, *, task: str = "", max_tokens: int = 4096) -> Any: ...


def extract_json(text: str) -> Any:
    """Parse JSON from model output, tolerating code fences and surrounding prose."""
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[1] if "\n" in cleaned else cleaned
        if cleaned.rstrip().endswith("```"):
            cleaned = cleaned.rstrip()[:-3]
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    decoder = json.JSONDecoder()
    for i, ch in enumerate(cleaned):
        if ch in "{[":
            try:
                value, _ = decoder.raw_decode(cleaned[i:])
                return value
            except json.JSONDecodeError:
                continue
    raise LLMError("The model did not return valid JSON.")


class _JsonMixin:
    def complete_json(self, system: str, prompt: str, *, task: str = "", max_tokens: int = 4096) -> Any:
        text = self.complete(system, prompt, task=task, max_tokens=max_tokens)  # type: ignore[attr-defined]
        try:
            return extract_json(text)
        except LLMError:
            retry = self.complete(  # type: ignore[attr-defined]
                system,
                prompt + "\n\nYour previous reply was not valid JSON. Reply with ONLY the JSON, nothing else.",
                task=task,
                max_tokens=max_tokens,
            )
            return extract_json(retry)


class AnthropicLLM(_JsonMixin):
    URL = "https://api.anthropic.com/v1/messages"

    def __init__(self, model: str | None = None):
        self.model = model or config.optional("LLM_MODEL", "claude-sonnet-5-5")

    def complete(self, system: str, prompt: str, *, task: str = "", max_tokens: int = 4096) -> str:
        data = post_json(
            self.URL,
            {
                "model": self.model,
                "max_tokens": max_tokens,
                "system": system,
                "messages": [{"role": "user", "content": prompt}],
            },
            headers={"x-api-key": config.require("ANTHROPIC_API_KEY"), "anthropic-version": "2023-06-01"},
        )
        parts = [b.get("text", "") for b in data.get("content", []) if b.get("type") == "text"]
        if not parts:
            raise LLMError("Anthropic returned no text.")
        return "".join(parts)


class OpenAILLM(_JsonMixin):
    URL = "https://api.openai.com/v1/chat/completions"

    def __init__(self, model: str | None = None):
        self.model = model or config.require("LLM_MODEL")  # no guessed default: model names change

    def complete(self, system: str, prompt: str, *, task: str = "", max_tokens: int = 4096) -> str:
        data = post_json(
            self.URL,
            {
                "model": self.model,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
            },
            headers={"Authorization": f"Bearer {config.require('OPENAI_API_KEY')}"},
        )
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError):
            raise LLMError("OpenAI returned an unexpected response.") from None


def make_llm() -> LLM:
    provider = config.optional("LLM_PROVIDER", "anthropic").lower()
    if provider == "anthropic":
        return AnthropicLLM()
    if provider == "openai":
        return OpenAILLM()
    raise LLMError(f"Unknown LLM_PROVIDER {provider!r}. Use 'anthropic' or 'openai'.")

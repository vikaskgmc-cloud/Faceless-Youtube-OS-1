"""Status pipeline and human approval gates.

The rules from the ChatGPT plan, enforced in code rather than by habit:
  * a project can only move to the *next* status;
  * topic, research, script and thumbnail need an explicit human approval;
  * nothing here publishes a video. PUBLISHED is only ever set by a human
    saying they uploaded it themselves.
"""
from __future__ import annotations

from .models import STATUSES, Project, now_iso


class GateError(Exception):
    """A step was attempted out of order or without the required approval."""


# approvals that must already be recorded before a status can be entered
REQUIRED_APPROVALS: dict[str, list[str]] = {
    "SELECTED": ["topic"],
    "SCRIPTING": ["research"],
    "APPROVED": ["script"],
    "UPLOAD_READY": ["thumbnail"],
}

# approvals that become invalid when an earlier step is redone
DOWNSTREAM: dict[str, list[str]] = {
    "research": ["research", "script", "thumbnail"],
    "script": ["script", "thumbnail"],
}


def approve(project: Project, name: str, by: str = "human", note: str = "") -> None:
    project.approvals[name] = {"at": now_iso(), "by": by, "note": note}


def revoke(project: Project, step: str) -> list[str]:
    """Drop approvals that depended on `step`; returns the names removed."""
    removed = [n for n in DOWNSTREAM.get(step, [step]) if project.approvals.pop(n, None) is not None]
    return removed


def advance(project: Project, target: str, note: str = "") -> None:
    if target not in STATUSES:
        raise GateError(f"Unknown status {target!r}.")
    if target == project.status:
        return
    here = STATUSES.index(project.status)
    there = STATUSES.index(target)
    if there != here + 1:
        nxt = STATUSES[here + 1] if here + 1 < len(STATUSES) else "nothing (pipeline finished)"
        raise GateError(f"Cannot go from {project.status} to {target}. The next step is {nxt}.")
    missing = [a for a in REQUIRED_APPROVALS.get(target, []) if a not in project.approvals]
    if missing:
        raise GateError(f"Cannot enter {target}: missing human approval for {', '.join(missing)}.")
    project.history.append({"at": now_iso(), "from": project.status, "to": target, "note": note})
    project.status = target
    project.updated = now_iso()


def require_status(project: Project, allowed: tuple[str, ...], action: str) -> None:
    if project.status not in allowed:
        raise GateError(
            f"Cannot {action} while the project is {project.status}. Allowed at: {', '.join(allowed)}."
        )

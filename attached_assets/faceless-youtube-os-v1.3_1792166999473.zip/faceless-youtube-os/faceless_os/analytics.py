"""Analytics: the plan's decision tree and retention-curve reading.

There are no universal "good" CTR or retention numbers, so every video is
compared against the channel's OWN earlier videos.
"""
from __future__ import annotations

import statistics
from pathlib import Path
from typing import Any

MIN_BASELINE_VIDEOS = 3

DECISIONS = {
    (True, True): ("make_more", "Concept and execution both work. Make more like this."),
    (True, False): ("fix_content", "Packaging works but the video disappoints. Fix the script and pacing."),
    (False, True): ("fix_packaging", "Good video, weak packaging. Rewrite the title and thumbnail."),
    (False, False): ("wrong_concept", "Wrong concept. Move on rather than polishing it."),
}


def baseline_from(history: list[dict[str, float]], min_videos: int = MIN_BASELINE_VIDEOS) -> dict[str, float] | None:
    rows = [h for h in history if "ctr" in h and "retention" in h]
    if len(rows) < min_videos:
        return None
    return {
        "ctr": statistics.median(h["ctr"] for h in rows),
        "retention": statistics.median(h["retention"] for h in rows),
        "videos": len(rows),
    }


def diagnose(ctr: float, retention: float, baseline: dict[str, float] | None) -> dict[str, Any]:
    if not baseline:
        return {
            "verdict": "insufficient_baseline",
            "action": f"Fewer than {MIN_BASELINE_VIDEOS} earlier videos to compare with. Publish more and judge against your own results.",
        }
    high_ctr = ctr >= baseline["ctr"]
    high_ret = retention >= baseline["retention"]
    verdict, action = DECISIONS[(high_ctr, high_ret)]
    return {"verdict": verdict, "action": action, "ctr_vs_baseline": round(ctr - baseline["ctr"], 2), "retention_vs_baseline": round(retention - baseline["retention"], 2)}


def parse_time(text: str) -> float:
    parts = [float(p) for p in text.strip().split(":")]
    seconds = 0.0
    for p in parts:
        seconds = seconds * 60 + p
    return seconds


def parse_curve(path: str | Path) -> list[tuple[float, float]]:
    """CSV with `time,percent` per line (time as seconds or mm:ss); a header line is ignored."""
    points = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if "," not in line:
            continue
        t, pct = line.split(",", 1)
        try:
            points.append((parse_time(t), float(pct.strip().rstrip("%"))))
        except ValueError:
            continue  # header or junk line
    return sorted(points)


def retention_at(points: list[tuple[float, float]], t: float) -> float | None:
    if not points or t < points[0][0] or t > points[-1][0]:
        return None
    for (t0, p0), (t1, p1) in zip(points, points[1:]):
        if t0 <= t <= t1:
            return round(p0 if t1 == t0 else p0 + (p1 - p0) * (t - t0) / (t1 - t0), 1)
    return points[-1][1]


def scene_at(timeline: list[dict[str, Any]], t: float) -> dict[str, Any] | None:
    for entry in timeline:
        if entry["start"] <= t < entry["end"]:
            return entry
    return timeline[-1] if timeline and t >= timeline[-1]["end"] else None


def retention_insights(points: list[tuple[float, float]], timeline: list[dict[str, Any]]) -> dict[str, Any]:
    if len(points) < 2:
        return {"error": "Need at least two points on the retention curve."}
    deltas = [((t0, p0), (t1, p1), p1 - p0) for (t0, p0), (t1, p1) in zip(points, points[1:])]
    worst = min(deltas, key=lambda d: d[2])
    best = max(deltas, key=lambda d: d[2])

    def describe(d: tuple[Any, Any, float]) -> dict[str, Any]:
        (t0, _), (t1, _), delta = d
        mid = (t0 + t1) / 2
        scene = scene_at(timeline, mid)
        return {"from": t0, "to": t1, "change_points": round(delta, 1), "scene": scene["scene"] if scene else None, "section": scene["section"] if scene else None}

    return {
        "retention_30s": retention_at(points, 30.0),
        "biggest_drop": describe(worst),
        "biggest_rise": describe(best) if best[2] > 0 else None,  # a rise suggests a moment worth repeating
    }

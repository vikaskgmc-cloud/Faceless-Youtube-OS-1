"""Command line: one command per step, with a human decision at every gate.

    python -m faceless_os new "Why Japan has millions of empty houses" --pillar countries
    python -m faceless_os score 001 --curiosity 22 --audience 16 ...
    python -m faceless_os select 001
    ...
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

from . import config, scoring
from .analytics import parse_curve  # noqa: F401  (re-exported for convenience)
from .http import HttpError
from .llm import LLMError, make_llm
from .media import MediaError
from .models import CLAIM_STATUSES
from .pipeline import Pipeline
from .research import ResearchError
from .scoring import ScoreError
from .search import Firecrawl, ManualSources, SearchError
from .story import ScriptError
from .storage import ProjectStore, StoreError
from .visuals import Pexels
from .voice import ElevenLabs, VoiceError
from .workflow import GateError

KNOWN_ERRORS = (
    GateError, StoreError, config.MissingSecret, ResearchError, ScriptError, ScoreError,
    VoiceError, MediaError, HttpError, LLMError, SearchError, FileNotFoundError, ValueError, KeyError,
)


NEXT_HUMAN_STEP = {
    "IDEA": "score the topic, then `select`.",
    "SELECTED": "run `autopilot` again (research is next).",
    "RESEARCH_COMPLETE": "read `claims`, fix any with `claim`, then `approve-research`, then `autopilot` again.",
    "SCRIPT_REVIEW": "read/edit the script (`export-script`, `import-script`), then `approve-script`, then `autopilot` again.",
    "QA": "review the rough cut and `titles`, then `approve-thumbnail --title ...`, then `ready`.",
    "UPLOAD_READY": "upload the video yourself, then `published --url ...`.",
}


def parse_size(text: str) -> tuple[int, int]:
    t = text.lower()
    if t in ("4k", "uhd"):
        return 3840, 2160
    if t in ("hd", "1080p"):
        return 1920, 1080
    w, h = (int(x) for x in t.split("x"))
    return w, h


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="faceless_os", description="Faceless YouTube OS: human-in-the-loop production line.")
    p.add_argument("--data", default=os.environ.get("FACELESS_DATA", "data/projects"), help="projects folder")
    sub = p.add_subparsers(dest="cmd", required=True)

    def add(name: str, help_: str, *args: tuple[str, dict[str, Any]]) -> argparse.ArgumentParser:
        sp = sub.add_parser(name, help=help_)
        for flag, kw in args:
            sp.add_argument(flag, **kw)
        return sp

    ref = ("ref", {"help": "project id or prefix, e.g. 001"})
    add("new", "create a project", ("topic", {}), ("--pillar", {"default": ""}), ("--title", {"default": ""}), ("--series", {"default": "", "help": "recurring series name, e.g. a format viewers return to"}))
    add("next-idea", "set the next video this one should tease (the return loop)", ref, ("idea", {}))
    add("list", "list projects")
    add("show", "show a project", ref, ("--json", {"action": "store_true"}))
    sc = add("score", "score a topic (100-point formula)", ref, ("--suggest", {"action": "store_true", "help": "ask the AI for a first pass"}), ("--confirm", {"action": "store_true", "help": "accept the AI suggestion"}))
    for name, top in scoring.MAXIMA.items():
        sc.add_argument(f"--{name}", type=float, help=f"0-{top}")
    sc.add_argument("--difficulty", type=float, default=0, help="penalty 0-5")
    add("select", "HUMAN GATE: approve the topic", ref, ("--override", {"default": "", "help": "reason, to proceed below the threshold"}))
    add("research", "run the research agent", ref, ("--sources", {"help": "JSON file of pages instead of live search"}), ("--per-question", {"type": int, "default": 4}))
    add("claims", "list claims", ref, ("--status", {"choices": CLAIM_STATUSES}))
    add("claim", "HUMAN: set a claim's status", ref, ("claim_id", {}), ("--status", {"required": True, "choices": CLAIM_STATUSES}), ("--note", {"default": ""}))
    add("approve-research", "HUMAN GATE: approve the research", ref)
    add("script", "write the story script (verified claims only)", ref, ("--min-claims", {"type": int, "default": 5}))
    add("factcheck", "fact-check the script", ref)
    add("export-script", "write script.json and script.md for editing", ref)
    add("import-script", "load an edited script.json", ref, ("file", {}))
    add("approve-script", "HUMAN GATE: approve the script", ref)
    add("voice", "narration with ElevenLabs", ref, ("--dry-run", {"action": "store_true"}))
    add("visuals", "collect Pexels footage", ref, ("--dry-run", {"action": "store_true"}), ("--per-scene", {"type": int, "default": 3}), ("--quality", {"choices": ["hd", "4k"], "default": "hd"}))
    add("assemble", "render the cut (captions.srt, loudness, optional music)", ref, ("--size", {"default": "1920x1080", "help": "WxH, or 4k / hd"}), ("--music", {"help": "royalty-free music file; it ducks under the voice"}), ("--burn-captions", {"action": "store_true", "help": "burn subtitles into the picture (needs libass)"}))
    add("autopilot", "run every machine step up to the next human gate", ref, ("--quality", {"choices": ["hd", "4k"], "default": "hd", "help": "4k = 3840x2160 cut from 4K footage"}), ("--music", {"help": "royalty-free music file"}))
    add("qa", "quality checklist", ref)
    add("titles", "generate title families and a thumbnail concept", ref)
    add("approve-thumbnail", "HUMAN GATE: approve title + thumbnail", ref, ("--title", {"required": True, "help": "family name (curiosity, mystery, contrarian, scale, question) or your own title"}), ("--words", {"default": ""}))
    add("ready", "build the upload package (you upload it yourself)", ref)
    add("published", "HUMAN: record the URL of the video you uploaded", ref, ("--url", {"required": True}))
    add("analyze", "record results and get the diagnosis", ref, ("--ctr", {"type": float, "required": True, "help": "click-through rate, %"}), ("--retention", {"type": float, "required": True, "help": "average percentage viewed, %"}), ("--curve", {"help": "CSV of time,percent from the retention graph"}))
    return p


def _print_report(report: dict[str, Any]) -> None:
    for b in report["blocking"]:
        print(f"  BLOCKING  {b['scene']}: {b['message']}")
    for w in report["warnings"]:
        print(f"  warning   {w['scene']}: {w['message']}")
    s = report["stats"]
    print(f"  {s['scenes']} scenes, {s['words']} words, about {s['est_minutes']} min; {len(s['claims_used'])} claims used")
    print("  result:", "PASS" if report["ok"] else "FAIL")


def run(argv: list[str] | None = None) -> int:
    config.load_dotenv()
    args = build_parser().parse_args(argv)
    store = ProjectStore(args.data)
    try:
        return _dispatch(args, store)
    except KNOWN_ERRORS as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


def _dispatch(args: argparse.Namespace, store: ProjectStore) -> int:
    c = args.cmd
    if c == "new":
        p = Pipeline(store).new_project(args.topic, args.pillar, args.title, args.series)
        print(f"Created {p.id}  (status {p.status})")
    elif c == "next-idea":
        p = Pipeline(store).set_next_idea(args.ref, args.idea)
        print(f"{p.id} will tease: {p.next_idea or '(nothing)'}")
    elif c == "list":
        for p in store.list():
            print(f"{p.id:45} {p.status:18} {p.title or p.topic}")
    elif c == "show":
        p = store.load(args.ref)
        if args.json:
            print(json.dumps(p.to_dict(), indent=2, ensure_ascii=False))
        else:
            claims = p.claims()
            print(f"{p.id}: {p.title or p.topic}\n  status: {p.status}\n  approvals: {', '.join(p.approvals) or 'none'}")
            if p.score:
                print(f"  score: {p.score['total']}/{p.score['max_possible']} (needs {p.score['threshold']}), confirmed={p.score.get('confirmed')}")
            print(f"  claims: {sum(1 for x in claims if x.status == 'verified')} verified of {len(claims)}")
            print(f"  scenes: {len(p.scenes())}")
    elif c == "score":
        pipe = Pipeline(store, llm=make_llm() if args.suggest else None)
        if args.suggest:
            p = pipe.suggest_score(args.ref)
            print("AI suggestion (not final):", p.score["total"], "-", p.score.get("rationale", ""))
            print("Review it, then run `score --confirm` or enter your own numbers.")
        elif args.confirm:
            pipe.confirm_score(args.ref)
            print("Score confirmed.")
        else:
            comps = {n: getattr(args, n) for n in scoring.MAXIMA}
            missing = [n for n, v in comps.items() if v is None]
            if missing:
                raise ValueError(f"Give a score for: {', '.join(missing)} (or use --suggest).")
            comps["difficulty"] = args.difficulty
            p = pipe.set_score(args.ref, comps)
            print(f"Total {p.score['total']} / {p.score['max_possible']}; production needs {p.score['threshold']}: {'PASS' if p.score['passes'] else 'below threshold'}")
    elif c == "select":
        p = Pipeline(store).select(args.ref, args.override)
        print(f"Topic approved. {p.id} is now {p.status}.")
    elif c == "research":
        search = ManualSources(args.sources) if args.sources else Firecrawl()
        p = Pipeline(store, llm=make_llm(), search=search).run_research(args.ref, args.per_question)
        claims = p.claims()
        print(f"{len(claims)} claims; {sum(1 for x in claims if x.status == 'verified')} verified by quote-match. Status {p.status}.")
        for e in p.research.get("errors", []):
            print(f"  note: {e['question'][:70]} -> {e['error']}")
        print("Review with `claims`, fix with `claim`, then `approve-research`.")
    elif c == "claims":
        for x in store.load(args.ref).claims():
            if args.status and x.status != args.status:
                continue
            print(f"{x.id} [{x.status:14}] {x.claim}\n      {x.source_url}" + (f"\n      note: {x.note}" if x.note else ""))
    elif c == "claim":
        Pipeline(store).set_claim(args.ref, args.claim_id, args.status, args.note)
        print("Claim updated. Research approval (if any) was withdrawn; approve again.")
    elif c == "approve-research":
        Pipeline(store).approve_research(args.ref)
        print("Research approved.")
    elif c == "script":
        p = Pipeline(store, llm=make_llm()).write_script(args.ref, args.min_claims)
        print(f"Script written (revision {len(p.script['revisions'])}). Status {p.status}.")
        _print_report(p.script["factcheck"])
    elif c == "factcheck":
        _print_report(Pipeline(store).run_factcheck(args.ref))
    elif c == "export-script":
        js, md = Pipeline(store).export_script(args.ref)
        print(f"Wrote {md} (to read) and {js} (to edit, then `import-script`).")
    elif c == "import-script":
        p = Pipeline(store).import_script(args.ref, args.file)
        _print_report(p.script["factcheck"])
    elif c == "approve-script":
        p = Pipeline(store).approve_script(args.ref)
        print(f"Script approved. {p.id} is now {p.status}.")
    elif c == "voice":
        pipe = Pipeline(store, tts=None if args.dry_run else ElevenLabs())
        print(json.dumps(pipe.make_voice(args.ref, dry_run=args.dry_run), indent=2))
    elif c == "visuals":
        pipe = Pipeline(store, video_search=None if args.dry_run else Pexels())
        print(json.dumps(pipe.find_visuals(args.ref, dry_run=args.dry_run, per_scene=args.per_scene, quality=args.quality), indent=2))
    elif c == "assemble":
        print(json.dumps(Pipeline(store).assemble(args.ref, size=parse_size(args.size), music=args.music, burn_captions=args.burn_captions), indent=2))
    elif c == "autopilot":
        size = (3840, 2160) if args.quality == "4k" else (1920, 1080)
        pipe = Pipeline(store, llm=make_llm(), search=Firecrawl(), tts=ElevenLabs(), video_search=Pexels())
        before = store.load(args.ref).status
        steps = pipe.autopilot(args.ref, quality=args.quality, size=size, music=args.music)
        p = store.load(args.ref)
        print(f"{before} -> {p.status}. Done: {', '.join(steps) or 'nothing to do'}.")
        print("Next, YOU decide:", NEXT_HUMAN_STEP.get(p.status, "nothing pending; see `show`."))
    elif c == "qa":
        report = Pipeline(store).qa(args.ref)
        for chk in report["checks"]:
            print(f"  [{'ok' if chk['ok'] else 'FAIL' if chk['level'] == 'required' else 'warn'}] {chk['name']}")
        print("QA:", "PASSED" if report["passed"] else "not passed")
    elif c == "titles":
        pkg = Pipeline(store, llm=make_llm()).make_titles(args.ref)
        for family, t in pkg["titles"].items():
            flags = "; ".join(i["message"] for i in pkg["issues"][family])
            print(f"  {family:11} {t}" + (f"   <- {flags}" if flags else ""))
        print(f"  thumbnail   {pkg['thumbnail']['words']}  ({pkg['thumbnail']['visual']})")
    elif c == "approve-thumbnail":
        p = Pipeline(store).approve_thumbnail(args.ref, args.title, args.words)
        print(f"Approved: {p.title}. Status {p.status}.")
    elif c == "ready":
        print("Upload package:", Pipeline(store).ready(args.ref))
    elif c == "published":
        p = Pipeline(store).mark_published(args.ref, args.url)
        print(f"Recorded. {p.id} is now {p.status}.")
    elif c == "analyze":
        print(json.dumps(Pipeline(store).record_analytics(args.ref, args.ctr, args.retention, args.curve), indent=2))
    return 0


def main() -> None:
    sys.exit(run())


if __name__ == "__main__":
    main()

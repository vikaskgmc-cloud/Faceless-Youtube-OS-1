"""Narration: approved script -> spoken text -> chunks -> ElevenLabs -> narration.mp3.

* One fixed voice (the voice is part of the brand): ELEVENLABS_VOICE_ID.
* Long scripts are split on paragraph/sentence boundaries (default 5,000 characters).
* Every chunk is saved as it finishes, so a failure part-way can resume without
  paying to regenerate chunks that already exist.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import tempfile
from pathlib import Path
from typing import Protocol

from . import config, media
from .http import request

DEFAULT_MAX_CHARS = 5000


class VoiceError(RuntimeError):
    pass


class TTS(Protocol):
    def synthesize(self, text: str) -> bytes: ...


def _hard_split(sentence: str, limit: int) -> list[str]:
    parts = []
    while len(sentence) > limit:
        cut = sentence.rfind(" ", 0, limit)
        cut = cut if cut > 0 else limit
        parts.append(sentence[:cut].strip())
        sentence = sentence[cut:].strip()
    if sentence:
        parts.append(sentence)
    return parts


def chunk_text(text: str, limit: int = DEFAULT_MAX_CHARS) -> list[str]:
    """Pack paragraphs into chunks of at most `limit` characters, never cutting mid-sentence if avoidable."""
    pieces: list[tuple[str, str]] = []  # (separator before, text)
    for paragraph in (p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()):
        if len(paragraph) <= limit:
            parts = [paragraph]
        else:
            parts = []
            for sentence in re.split(r"(?<=[.!?])\s+", paragraph):
                parts.extend(_hard_split(sentence, limit) if len(sentence) > limit else [sentence])
        for i, part in enumerate(parts):
            pieces.append(("\n\n" if i == 0 else " ", part))
    chunks: list[str] = []
    current = ""
    for sep, piece in pieces:
        candidate = current + sep + piece if current else piece
        if len(candidate) <= limit:
            current = candidate
        else:
            if current:
                chunks.append(current)
            current = piece
    if current:
        chunks.append(current)
    return chunks


class ElevenLabs:
    def __init__(self, voice_id: str | None = None, model_id: str | None = None):
        self._voice_id = voice_id
        self._model_id = model_id

    def synthesize(self, text: str) -> bytes:
        voice = self._voice_id or config.require("ELEVENLABS_VOICE_ID")
        model = self._model_id or config.optional("ELEVENLABS_MODEL", "eleven_multilingual_v2")
        return request(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice}",
            method="POST",
            headers={"xi-api-key": config.require("ELEVENLABS_API_KEY"), "Accept": "audio/mpeg"},
            payload={"text": text, "model_id": model},
            timeout=300,
        )


def _merge(files: list[Path], dest: Path) -> None:
    if len(files) == 1:
        shutil.copyfile(files[0], dest)
    elif media.have_ffmpeg():
        with tempfile.TemporaryDirectory() as tmp:
            listing = Path(tmp) / "list.txt"
            listing.write_text("".join(f"file '{f.resolve()}'\n" for f in files), encoding="utf-8")
            media.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(listing), "-c", "copy", str(dest)])
    else:  # MP3 frames can be appended safely when ffmpeg is unavailable
        with open(dest, "wb") as out:
            for f in files:
                out.write(f.read_bytes())


def narrate(text: str, out_dir: Path, tts: TTS, *, max_chars: int = DEFAULT_MAX_CHARS) -> dict:
    chunks = chunk_text(text, max_chars)
    if not chunks:
        raise VoiceError("There is no narration text.")
    chunk_dir = out_dir / "chunks"
    chunk_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = out_dir / "chunks.json"
    manifest: dict[str, str] = json.loads(manifest_path.read_text()) if manifest_path.is_file() else {}

    files: list[Path] = []
    reused = 0
    for i, chunk in enumerate(chunks, 1):
        path = chunk_dir / f"{i:03d}.mp3"
        digest = hashlib.sha1(chunk.encode("utf-8")).hexdigest()
        if path.is_file() and path.stat().st_size > 0 and manifest.get(path.name) == digest:
            files.append(path)
            reused += 1
            continue
        audio = tts.synthesize(chunk)
        if not audio:
            raise VoiceError(f"The voice service returned no audio for chunk {i}.")
        path.write_bytes(audio)
        manifest[path.name] = digest
        manifest_path.write_text(json.dumps(manifest, indent=2))
        files.append(path)

    merged = out_dir / "narration.mp3"
    _merge(files, merged)
    return {
        "file": str(merged),
        "chunks": len(chunks),
        "reused_chunks": reused,
        "characters": len(text),
        "duration": round(media.duration(merged), 2) if media.have_ffmpeg() else None,
    }

"""Stock footage from Pexels, with a source/credit record for every clip.

Pexels asks API users to link to Pexels prominently and recommends crediting the
creator, so credits.md is generated next to the footage.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlencode

from . import config
from .http import download, get_json
from .models import Scene

MIN_WIDTH = 1280
MAX_WIDTH = 1920


class VideoSearch(Protocol):
    def search(self, query: str, per_page: int = 8) -> list[dict[str, Any]]: ...


class Pexels:
    URL = "https://api.pexels.com/videos/search"

    def search(self, query: str, per_page: int = 8) -> list[dict[str, Any]]:
        qs = urlencode({"query": query, "orientation": "landscape", "per_page": per_page})
        data = get_json(f"{self.URL}?{qs}", headers={"Authorization": config.require("PEXELS_API_KEY")})
        return data.get("videos", [])


QUALITY_WIDTHS = {"hd": (1280, 1920), "4k": (2560, 3840)}


def choose_file(video: dict[str, Any], quality: str = "hd") -> dict[str, Any] | None:
    """Best mp4 rendition for the quality tier: the widest inside its band, else the widest below it,
    else the smallest available (the rough cut upscales it, and QA reports that)."""
    low, high = QUALITY_WIDTHS[quality]
    files = [f for f in video.get("video_files", []) if f.get("file_type") == "video/mp4" and f.get("width") and f.get("link")]
    if not files:
        return None
    ideal = [f for f in files if low <= f["width"] <= high]
    if ideal:
        return max(ideal, key=lambda f: f["width"])
    under = [f for f in files if f["width"] <= high]
    if under:
        return max(under, key=lambda f: f["width"])
    return min(files, key=lambda f: f["width"])


def find_clips(scenes: list[Scene], search: VideoSearch, per_scene: int = 3, quality: str = "hd") -> dict[str, list[dict[str, Any]]]:
    used: set[int] = set()
    selection: dict[str, list[dict[str, Any]]] = {}
    for scene in scenes:
        query = scene.visual_query or " ".join(scene.narration.split()[:4])
        picks: list[dict[str, Any]] = []
        for video in search.search(query, per_page=per_scene + 5):
            if video.get("id") in used:
                continue
            chosen = choose_file(video, quality)
            if not chosen:
                continue
            user = video.get("user") or {}
            picks.append(
                {
                    "video_id": video.get("id"),
                    "pexels_url": video.get("url", ""),
                    "photographer": user.get("name", ""),
                    "photographer_url": user.get("url", ""),
                    "query": query,
                    "link": chosen["link"],
                    "width": chosen["width"],
                    "height": chosen.get("height"),
                    "duration": video.get("duration"),
                    "file": "",
                }
            )
            used.add(video.get("id"))
            if len(picks) >= per_scene:
                break
        selection[scene.id] = picks
    return selection


def download_clips(selection: dict[str, list[dict[str, Any]]], clips_dir: Path) -> None:
    for scene_id, clips in selection.items():
        for i, clip in enumerate(clips, 1):
            dest = clips_dir / f"{scene_id}_{i}.mp4"
            if not (dest.is_file() and dest.stat().st_size > 0):
                download(clip["link"], dest)
            clip["file"] = str(dest)


def write_credits(selection: dict[str, list[dict[str, Any]]], path: Path) -> None:
    lines = [
        "# Footage credits",
        "",
        "Video footage provided by [Pexels](https://www.pexels.com). Put this line in the video description.",
        "",
    ]
    for scene_id, clips in selection.items():
        for clip in clips:
            who = clip["photographer"] or "Pexels contributor"
            lines.append(f"- {scene_id}: Video by {who} on Pexels: {clip['pexels_url']}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

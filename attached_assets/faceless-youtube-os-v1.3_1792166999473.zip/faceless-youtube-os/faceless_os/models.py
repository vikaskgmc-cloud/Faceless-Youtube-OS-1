"""Data model for one video project.

A project moves through the status pipeline from the ChatGPT plan
(IDEA -> ... -> ANALYZING). Everything is plain dicts/lists underneath so the
project file stays human-readable JSON.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from typing import Any

STATUSES = [
    "IDEA",
    "SELECTED",
    "RESEARCHING",
    "RESEARCH_COMPLETE",
    "SCRIPTING",
    "SCRIPT_REVIEW",
    "APPROVED",
    "VOICE",
    "VISUALS",
    "EDITING",
    "QA",
    "THUMBNAIL",
    "UPLOAD_READY",
    "PUBLISHED",
    "ANALYZING",
]

CLAIM_STATUSES = ("verified", "needs_checking", "conflicting", "rejected")


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def slugify(text: str, max_len: int = 40) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug[:max_len].strip("-") or "video"


@dataclass
class Claim:
    """One factual claim with its evidence. Only `verified` claims may be scripted."""

    id: str
    claim: str
    source_url: str
    source_title: str = ""
    quote: str = ""  # exact words from the source page that back the claim
    date: str = ""  # publication date of the source, if known
    checked_on: str = ""  # day the page was opened
    confidence: str = "low"  # agent's own view: high | medium | low
    status: str = "needs_checking"  # verified | needs_checking | conflicting | rejected
    verified_by: str = ""  # "quote-match" (code) or "human"
    metric: str = ""  # what is measured, with year; used to spot conflicts
    question: str = ""
    note: str = ""


@dataclass
class Scene:
    id: str
    section: str
    narration: str
    visual_query: str = ""
    claim_ids: list[str] = field(default_factory=list)


def _research_default() -> dict[str, Any]:
    return {"questions": [], "claims": [], "summary": {}, "sources": [], "errors": [], "ran_at": ""}


def _script_default() -> dict[str, Any]:
    return {"scenes": [], "revisions": [], "factcheck": None}


@dataclass
class Project:
    id: str
    topic: str
    pillar: str = ""
    title: str = ""
    series: str = ""  # recurring format the viewer can return to
    next_idea: str = ""  # the specific story the closing line should tease
    status: str = "IDEA"
    created: str = field(default_factory=now_iso)
    updated: str = field(default_factory=now_iso)
    score: dict[str, Any] | None = None
    research: dict[str, Any] = field(default_factory=_research_default)
    script: dict[str, Any] = field(default_factory=_script_default)
    approvals: dict[str, Any] = field(default_factory=dict)
    titles: dict[str, Any] = field(default_factory=dict)
    assets: dict[str, Any] = field(default_factory=dict)
    publish: dict[str, Any] = field(default_factory=dict)
    analytics: list[dict[str, Any]] = field(default_factory=list)
    history: list[dict[str, Any]] = field(default_factory=list)

    # -- (de)serialisation -------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Project":
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in known})

    # -- typed views over the dicts ---------------------------------------
    def claims(self) -> list[Claim]:
        return [Claim(**c) for c in self.research.get("claims", [])]

    def set_claims(self, claims: list[Claim]) -> None:
        self.research["claims"] = [asdict(c) for c in claims]

    def verified_claims(self) -> list[Claim]:
        return [c for c in self.claims() if c.status == "verified"]

    def scenes(self) -> list[Scene]:
        return [Scene(**s) for s in self.script.get("scenes", [])]

    def set_scenes(self, scenes: list[Scene]) -> None:
        self.script["scenes"] = [asdict(s) for s in scenes]

"""Test doubles. All facts here are FICTIONAL ("Examplia"); they exist only to exercise the code."""
from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path

from faceless_os.search import SearchResult

PAGES = [
    SearchResult(
        "https://example.org/stats",
        "Examplia housing survey",
        "The 2023 survey counted 9,000,000 vacant homes in Examplia. That is 14% of all housing. "
        "Officials say the number has doubled since 1998.",
        "2024-02-01",
    ),
    SearchResult(
        "https://example.org/inheritance",
        "Why heirs cannot sell",
        "Inheritance rules in Examplia make it hard to sell a house when the heirs cannot be found. "
        "Demolition costs an average of 25,000 credits.",
        "2023-11-10",
    ),
    SearchResult(
        "https://example.org/policy",
        "Free house programme",
        "In 2020 the government started a free-house programme, giving away 1,200 homes to families who agreed to stay.",
        "2023-05-05",
    ),
    SearchResult(
        "https://example.org/costs",
        "Maintenance burden",
        "Owners of empty homes still pay property tax every year, which discourages them from demolishing the building.",
        "2022-09-09",
    ),
    SearchResult(
        "https://example.org/rural",
        "Rural decline",
        "Young people moved to the capital for work, and many villages in Examplia now have more empty houses than residents.",
        "2023-01-15",
    ),
    SearchResult(
        "https://example.org/rival",
        "Private study",
        "A private study counted 8,500,000 vacant homes in Examplia in 2023.",
        "2024-03-01",
    ),
]

# claim text -> (page url, exact quote, metric)
EXTRACTIONS = {
    "https://example.org/stats": [
        ("Examplia had 9,000,000 vacant homes in 2023.", "The 2023 survey counted 9,000,000 vacant homes in Examplia.", "examplia vacant homes 2023"),
        ("Vacant homes are 14% of all housing in Examplia.", "That is 14% of all housing.", ""),
        ("The number of vacant homes has tripled since 1998.", "Officials say the number has doubled since 1998.", ""),  # wrong: 'tripled' not a number, but quote ok; used to test non-number drift
    ],
    "https://example.org/inheritance": [
        ("Heirs often cannot be found, which blocks sales.", "Inheritance rules in Examplia make it hard to sell a house when the heirs cannot be found.", ""),
        ("Demolition costs 30,000 credits on average.", "Demolition costs an average of 25,000 credits.", ""),  # number not in quote -> needs_checking
    ],
    "https://example.org/policy": [
        ("The government gave away 1,200 homes from 2020.", "In 2020 the government started a free-house programme, giving away 1,200 homes", ""),
    ],
    "https://example.org/costs": [
        ("Owners pay property tax on empty homes every year.", "Owners of empty homes still pay property tax every year", ""),
        ("Owners love empty houses.", "this sentence is not on the page at all, honestly", ""),  # fabricated quote
    ],
    "https://example.org/rural": [
        ("Many villages have more empty houses than residents.", "many villages in Examplia now have more empty houses than residents.", ""),
    ],
    "https://example.org/rival": [
        ("A private study counted 8,500,000 vacant homes in 2023.", "A private study counted 8,500,000 vacant homes in Examplia in 2023.", "examplia vacant homes 2023"),
    ],
}


class StaticSearch:
    def __init__(self, pages=PAGES):
        self.pages = pages
        self.queries: list[str] = []

    def search(self, query: str, limit: int = 4):
        self.queries.append(query)
        return list(self.pages)[:limit]


class ScriptedLLM:
    """Returns canned JSON per task; callables receive the JSON payload the pipeline sent."""

    def __init__(self, responses: dict):
        self.responses = responses
        self.calls: list[str] = []

    def complete(self, *a, **k):  # pragma: no cover
        raise NotImplementedError

    def complete_json(self, system: str, prompt: str, *, task: str = "", max_tokens: int = 4096):
        self.calls.append(task)
        r = self.responses[task]
        return r(json.loads(prompt)) if callable(r) else r


def extract_claims(payload: dict) -> dict:
    out = []
    for src in payload["sources"]:
        for text, quote, metric in EXTRACTIONS.get(src["url"], []):
            out.append(
                {"claim": text, "source_index": src["index"], "quote": quote, "date": src.get("date", ""), "confidence": "medium", "metric": metric}
            )
    out.append({"claim": "Invented source.", "source_index": 99, "quote": "x" * 40})  # index never shown -> dropped
    return {"claims": out}


def base_llm_responses(extra: dict | None = None) -> dict:
    def script(payload: dict) -> dict:
        ids = [c["id"] for c in payload["verified_claims"]]
        text = {c["id"]: c["claim"] for c in payload["verified_claims"]}
        scenes = []
        for i, section in enumerate(["hook", "promise", "setup", "discovery", "escalation", "big_reveal", "consequence", "next_curiosity"]):
            if section in ("promise", "next_curiosity"):
                scenes.append({"section": section, "narration": "So why does this keep happening? The next story is stranger.", "visual_query": "empty street", "claim_ids": []})
            else:
                cid = ids[i % len(ids)]
                scenes.append({"section": section, "narration": text[cid], "visual_query": "aerial city", "claim_ids": [cid]})
        return {"scenes": scenes}

    base = {
        "plan_questions": {"questions": ["How many homes are empty?", "Why can't owners sell?", "What is being done?", "What does it cost?"]},
        "extract_claims": extract_claims,
        "summarise_research": {"angle": "A country full of homes nobody can sell.", "surprising": ["Villages with more houses than people [C001]"], "open_questions": [], "title_ideas": ["x"] * 5},
        "write_script": script,
        "titles": {
            "titles": {"curiosity": "Why Nobody Can Sell These Homes", "mystery": "The Empty Houses of Examplia", "contrarian": "Empty Homes Aren't Free", "scale": "9,000,000 Empty Homes", "question": "Who Owns Examplia's Empty Houses?"},
            "thumbnail": {"words": "NOT FREE", "visual": "a lone house with a price tag", "emotion": "curiosity"},
        },
        "score_topic": {"curiosity": 22, "audience": 16, "story": 17, "visuals": 8, "evergreen": 8, "monetization": 7, "difficulty": 2, "rationale": "ok"},
    }
    base.update(extra or {})
    return base


class FakeTTS:
    """Makes a real MP3 whose length follows the text, so assembly can be tested for real."""

    def __init__(self):
        self.calls: list[int] = []

    def synthesize(self, text: str) -> bytes:
        self.calls.append(len(text))
        seconds = max(2.0, len(text.split()) / 4.0)
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "a.mp3"
            subprocess.run(
                ["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"sine=frequency=220:duration={seconds}", "-c:a", "libmp3lame", str(out)],
                check=True,
            )
            return out.read_bytes()


class FakeVideoSearch:
    def search(self, query: str, per_page: int = 8):
        return [
            {
                "id": 1000 + i + sum(map(ord, query)),
                "url": f"https://www.pexels.com/video/{i}/",
                "duration": 5,
                "user": {"name": f"Maker {i}", "url": f"https://www.pexels.com/@maker{i}"},
                "video_files": [
                    {"file_type": "video/mp4", "width": 640, "height": 360, "link": "https://example.invalid/small.mp4"},
                    {"file_type": "video/mp4", "width": 1920, "height": 1080, "link": f"https://example.invalid/{i}.mp4"},
                ],
            }
            for i in range(per_page)
        ]


def make_test_clip(dest: Path, seconds: float = 5.0) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"testsrc=size=320x180:rate=15:duration={seconds}", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(dest)],
        check=True,
    )

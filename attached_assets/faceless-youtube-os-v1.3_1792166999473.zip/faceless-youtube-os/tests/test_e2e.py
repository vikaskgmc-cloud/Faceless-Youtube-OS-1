"""The whole production line, offline, with fakes: gates must hold at every step."""
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from faceless_os import cli, media
from faceless_os.pipeline import Pipeline
from faceless_os.storage import ProjectStore
from faceless_os.workflow import GateError
from tests.fakes import PAGES, FakeTTS, FakeVideoSearch, ScriptedLLM, StaticSearch, base_llm_responses, make_test_clip


def fake_download(url, dest, timeout=300):
    make_test_clip(Path(dest), 5)
    return Path(dest)


@unittest.skipUnless(media.have_ffmpeg(), "ffmpeg not installed")
class EndToEndTests(unittest.TestCase):
    def test_full_line_with_every_gate(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch("faceless_os.visuals.download", fake_download):
            store = ProjectStore(tmp)
            pipe = Pipeline(store, llm=ScriptedLLM(base_llm_responses()), search=StaticSearch(PAGES), tts=FakeTTS(), video_search=FakeVideoSearch())
            pid = pipe.new_project("Why Examplia has so many empty houses", "countries").id

            # --- gates hold from the very start
            with self.assertRaises(GateError):
                pipe.run_research(pid)  # topic not selected
            pipe.suggest_score(pid)
            with self.assertRaises(GateError):
                pipe.select(pid)  # AI suggestion not yet confirmed by a human
            pipe.confirm_score(pid)
            pipe.select(pid)
            self.assertEqual(store.load(pid).status, "SELECTED")

            # --- research, then a human gate before scripting
            pipe.run_research(pid, results_per_question=6)
            p = store.load(pid)
            self.assertEqual(p.status, "RESEARCH_COMPLETE")
            with self.assertRaises(GateError):
                pipe.write_script(pid)  # research not approved
            with self.assertRaises(GateError):
                pipe.set_claim(pid, "C002", "verified", "")  # hand-verification needs a note
            pipe.approve_research(pid)

            # --- changing evidence withdraws the approval
            unverified = next(c for c in p.claims() if c.status == "needs_checking")
            pipe.set_claim(pid, unverified.id, "rejected", "not on the page")
            self.assertNotIn("research", store.load(pid).approvals)
            with self.assertRaises(GateError):
                pipe.write_script(pid)
            pipe.approve_research(pid)

            # --- script + fact-check gate
            pipe.write_script(pid)
            p = store.load(pid)
            self.assertEqual(p.status, "SCRIPT_REVIEW")
            self.assertTrue(p.script["factcheck"]["ok"])
            with self.assertRaises(GateError):
                pipe.make_voice(pid)  # script not approved yet

            # a human edit that adds an unsourced figure must be blocked at the gate
            js, md = pipe.export_script(pid)
            edited = json.loads(js.read_text())
            edited["scenes"][0]["narration"] += " Some say 77,777 more are hidden."
            js.write_text(json.dumps(edited))
            pipe.import_script(pid, js)
            self.assertFalse(store.load(pid).script["factcheck"]["ok"])
            with self.assertRaises(GateError):
                pipe.approve_script(pid)
            edited["scenes"][0]["narration"] = edited["scenes"][0]["narration"].replace(" Some say 77,777 more are hidden.", "")
            js.write_text(json.dumps(edited))
            pipe.import_script(pid, js)
            self.assertEqual(len(store.load(pid).script["revisions"]), 3)
            pipe.approve_script(pid)
            self.assertEqual(store.load(pid).status, "APPROVED")

            # --- voice (dry run changes nothing), then real
            plan = pipe.make_voice(pid, dry_run=True)
            self.assertTrue(plan["dry_run"])
            self.assertEqual(store.load(pid).status, "APPROVED")
            pipe.make_voice(pid)
            self.assertEqual(store.load(pid).status, "VOICE")

            # --- visuals, rough cut, QA
            pipe.find_visuals(pid, per_scene=2)
            self.assertEqual(store.load(pid).status, "VISUALS")
            pipe.assemble(pid, size=(320, 180))
            self.assertEqual(store.load(pid).status, "EDITING")
            qa = pipe.qa(pid)
            self.assertTrue(qa["passed"], qa)
            self.assertEqual(store.load(pid).status, "QA")

            # --- packaging gate
            pkg = pipe.make_titles(pid)
            self.assertEqual(pkg["thumbnail"]["words"], "NOT FREE")
            with self.assertRaises(GateError):
                pipe.approve_thumbnail(pid, "My own title with 99,999 invented homes")
            with self.assertRaises(GateError):
                pipe.ready(pid)
            pipe.approve_thumbnail(pid, "curiosity")
            self.assertEqual(store.load(pid).title, "Why Nobody Can Sell These Homes")
            package = pipe.ready(pid)
            text = package.read_text()
            self.assertIn("Nothing in this tool publishes", text)
            self.assertIn("https://example.org/", text)  # sources listed
            self.assertIn("Pexels", text)

            # --- only a human can mark published
            with self.assertRaises(GateError):
                pipe.mark_published(pid, "not a url")
            pipe.mark_published(pid, "https://youtube.com/watch?v=abc")
            p = store.load(pid)
            self.assertEqual((p.status, p.publish["by"]), ("PUBLISHED", "human"))

            # --- analytics (no baseline yet), with a retention curve mapped to scenes
            curve = Path(tmp) / "curve.csv"
            curve.write_text("0:00,100\n0:30,80\n0:60,50\n")
            out = pipe.record_analytics(pid, 5.2, 41.0, curve)
            self.assertEqual(out["diagnosis"]["verdict"], "insufficient_baseline")
            self.assertIsNotNone(out["retention"]["biggest_drop"]["scene"])
            self.assertEqual(store.load(pid).status, "ANALYZING")

            # --- the full history is recorded in order
            path = [h["to"] for h in store.load(pid).history]
            self.assertEqual(path[0], "SELECTED")
            self.assertEqual(path[-1], "ANALYZING")
            self.assertEqual(len(path), 14)

    @unittest.skipUnless(media.have_ffmpeg(), "ffmpeg not installed")
    def test_autopilot_stops_at_every_human_gate(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch("faceless_os.visuals.download", fake_download):
            store = ProjectStore(tmp)
            pipe = Pipeline(store, llm=ScriptedLLM(base_llm_responses()), search=StaticSearch(PAGES), tts=FakeTTS(), video_search=FakeVideoSearch())
            pid = pipe.new_project("Why Examplia has so many empty houses").id
            self.assertEqual(pipe.autopilot(pid), [])  # nothing to do before the topic is approved
            pipe.suggest_score(pid); pipe.confirm_score(pid); pipe.select(pid)
            self.assertEqual(pipe.autopilot(pid), ["research"])
            self.assertEqual(store.load(pid).status, "RESEARCH_COMPLETE")  # stops: research needs a human
            self.assertEqual(pipe.autopilot(pid), [])
            pipe.approve_research(pid)
            self.assertEqual(pipe.autopilot(pid), ["script + fact-check"])
            self.assertEqual(store.load(pid).status, "SCRIPT_REVIEW")  # stops: script needs a human
            pipe.approve_script(pid)
            done = pipe.autopilot(pid, quality="4k", size=(320, 180))  # small size keeps the test fast
            self.assertEqual(done[0], "voice")
            self.assertIn("QA passed", done)
            self.assertEqual(done[-1], "titles + thumbnail concept")
            self.assertEqual(store.load(pid).status, "QA")  # stops: title + thumbnail need a human
            self.assertEqual(store.load(pid).assets["visuals"]["quality"], "4k")
            self.assertNotIn("thumbnail", store.load(pid).approvals)

    def test_cannot_skip_ahead(self):
        with tempfile.TemporaryDirectory() as tmp:
            pipe = Pipeline(ProjectStore(tmp), llm=ScriptedLLM(base_llm_responses()))
            pid = pipe.new_project("topic").id
            for step in (pipe.approve_research, pipe.approve_script, pipe.ready, pipe.qa):
                with self.assertRaises(GateError):
                    step(pid)
            with self.assertRaises(GateError):
                pipe.mark_published(pid, "https://youtube.com/x")

    def test_low_score_needs_an_explicit_override(self):
        with tempfile.TemporaryDirectory() as tmp:
            pipe = Pipeline(ProjectStore(tmp))
            pid = pipe.new_project("weak idea").id
            pipe.set_score(pid, {"curiosity": 10, "audience": 10, "story": 10, "visuals": 5, "evergreen": 5, "monetization": 5})
            with self.assertRaises(GateError):
                pipe.select(pid)
            pipe.select(pid, override_reason="testing a hunch")
            self.assertIn("override", ProjectStore(tmp).load(pid).approvals["topic"]["note"])


class CliTests(unittest.TestCase):
    def test_cli_flow_and_error_messages(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(cli.run(["--data", tmp, "new", "Test topic"]), 0)
            self.assertEqual(cli.run(["--data", tmp, "list"]), 0)
            self.assertEqual(cli.run(["--data", tmp, "score", "001", "--curiosity", "22", "--audience", "17", "--story", "17", "--visuals", "8", "--evergreen", "8", "--monetization", "7", "--difficulty", "2"]), 0)
            self.assertEqual(cli.run(["--data", tmp, "select", "001"]), 0)
            self.assertEqual(cli.run(["--data", tmp, "show", "001"]), 0)
            self.assertEqual(cli.run(["--data", tmp, "approve-script", "001"]), 1)  # out of order -> clean error, no traceback
            self.assertEqual(cli.run(["--data", tmp, "show", "999"]), 1)

    def test_missing_secret_is_reported_without_a_traceback(self):
        with tempfile.TemporaryDirectory() as tmp:
            cli.run(["--data", tmp, "new", "Topic"])
            with mock.patch.dict("os.environ", {"LLM_PROVIDER": "anthropic", "ANTHROPIC_API_KEY": ""}):
                self.assertEqual(cli.run(["--data", tmp, "score", "001", "--curiosity", "22", "--audience", "16", "--story", "16", "--visuals", "8", "--evergreen", "8", "--monetization", "8"]), 0)
                self.assertEqual(cli.run(["--data", tmp, "select", "001"]), 0)
                pages = Path(tmp) / "pages.json"
                pages.write_text("[]")
                err = io.StringIO()
                with contextlib.redirect_stderr(err):
                    code = cli.run(["--data", tmp, "research", "001", "--sources", str(pages)])
                self.assertEqual(code, 1)
                self.assertIn("ANTHROPIC_API_KEY is not set", err.getvalue())
                self.assertNotIn("Traceback", err.getvalue())


if __name__ == "__main__":
    unittest.main()

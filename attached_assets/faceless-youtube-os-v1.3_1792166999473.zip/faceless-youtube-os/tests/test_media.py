import json
import tempfile
import unittest
from pathlib import Path

from faceless_os import analytics, assemble, media, visuals, voice
from faceless_os.models import Scene
from tests.fakes import FakeTTS, FakeVideoSearch, make_test_clip


class ChunkTests(unittest.TestCase):
    def test_chunks_never_exceed_limit_and_keep_all_text(self):
        para = " ".join(f"Sentence number {i} is here." for i in range(400))  # one huge paragraph
        text = "\n\n".join([para, "Short paragraph.", para])
        chunks = voice.chunk_text(text, 5000)
        self.assertTrue(all(len(c) <= 5000 for c in chunks))
        self.assertGreater(len(chunks), 2)
        joined = " ".join(chunks)
        self.assertEqual(joined.count("Sentence number 399 is here."), 2)
        self.assertIn("Short paragraph.", joined)

    def test_small_text_is_one_chunk_and_giant_sentence_is_split(self):
        self.assertEqual(voice.chunk_text("Hello.\n\nWorld.", 5000), ["Hello.\n\nWorld."])
        giant = "word " * 3000
        chunks = voice.chunk_text(giant, 1000)
        self.assertTrue(all(len(c) <= 1000 for c in chunks))
        self.assertEqual(sum(len(c.split()) for c in chunks), 3000)

    def test_empty(self):
        self.assertEqual(voice.chunk_text("  \n\n ", 100), [])


@unittest.skipUnless(media.have_ffmpeg(), "ffmpeg not installed")
class NarrateTests(unittest.TestCase):
    def test_resume_reuses_finished_chunks(self):
        text = "\n\n".join(f"Paragraph {i} " + "words " * 30 for i in range(6))
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            tts = FakeTTS()
            first = voice.narrate(text, out, tts, max_chars=400)
            made = len(tts.calls)
            self.assertGreater(first["chunks"], 2)
            self.assertEqual(made, first["chunks"])
            again = voice.narrate(text, out, tts, max_chars=400)
            self.assertEqual(len(tts.calls), made)  # nothing regenerated
            self.assertEqual(again["reused_chunks"], first["chunks"])
            self.assertGreater(again["duration"], 2)

    def test_failure_keeps_finished_chunks(self):
        class Dies(FakeTTS):
            def synthesize(self, text):
                if len(self.calls) == 2:
                    raise RuntimeError("quota")
                return super().synthesize(text)

        text = "\n\n".join(f"Paragraph {i} " + "words " * 30 for i in range(6))
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(RuntimeError):
                voice.narrate(text, Path(tmp), Dies(), max_chars=400)
            self.assertEqual(len(list((Path(tmp) / "chunks").glob("*.mp3"))), 2)


class VisualsTests(unittest.TestCase):
    def test_choose_file_prefers_hd_mp4(self):
        v = {"video_files": [
            {"file_type": "video/mp4", "width": 640, "link": "a"},
            {"file_type": "video/mp4", "width": 1920, "link": "b"},
            {"file_type": "video/mp4", "width": 3840, "link": "c"},
            {"file_type": "video/webm", "width": 1920, "link": "d"},
        ]}
        self.assertEqual(visuals.choose_file(v)["link"], "b")
        self.assertEqual(visuals.choose_file({"video_files": [{"file_type": "video/mp4", "width": 3840, "link": "c"}, {"file_type": "video/mp4", "width": 2560, "link": "e"}]})["link"], "e")
        self.assertIsNone(visuals.choose_file({"video_files": []}))

    def test_choose_file_4k_prefers_uhd_and_falls_back(self):
        v = {"video_files": [
            {"file_type": "video/mp4", "width": 1920, "link": "hd"},
            {"file_type": "video/mp4", "width": 3840, "link": "uhd"},
            {"file_type": "video/mp4", "width": 2560, "link": "qhd"},
        ]}
        self.assertEqual(visuals.choose_file(v, "4k")["link"], "uhd")
        self.assertEqual(visuals.choose_file(v, "hd")["link"], "hd")
        only_hd = {"video_files": [{"file_type": "video/mp4", "width": 1920, "link": "hd"}]}
        self.assertEqual(visuals.choose_file(only_hd, "4k")["link"], "hd")  # falls back; QA will warn

    def test_find_clips_avoids_duplicates_and_writes_credits(self):
        scenes = [Scene("S01", "hook", "a b c d", "city"), Scene("S02", "setup", "e f", "")]
        sel = visuals.find_clips(scenes, FakeVideoSearch(), per_scene=2)
        ids = [c["video_id"] for clips in sel.values() for c in clips]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertTrue(all(len(c) == 2 for c in sel.values()))
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "credits.md"
            visuals.write_credits(sel, path)
            text = path.read_text()
            self.assertIn("pexels.com", text)
            self.assertIn("Maker 0", text)


class ShotPlanTests(unittest.TestCase):
    def test_shots_stay_between_2_and_6_seconds(self):
        for d in [2.0, 2.5, 4.0, 5.9, 9.0, 13.0, 31.7, 100.0]:
            shots = assemble.plan_shots(d)
            self.assertAlmostEqual(sum(shots), d, places=6)
            self.assertTrue(all(2.0 - 1e-9 <= s <= 6.0 + 1e-9 for s in shots), (d, shots))
        self.assertEqual(assemble.plan_shots(1.2), [1.2])
        self.assertEqual(assemble.plan_shots(0), [])

    def test_durations_follow_word_counts(self):
        scenes = [Scene("S01", "hook", "one two"), Scene("S02", "setup", "one two three four six eight")]
        d = assemble.scene_durations(scenes, 80)
        self.assertAlmostEqual(d["S01"], 20)
        self.assertAlmostEqual(d["S02"], 60)

    def test_timeline_cycles_clips_and_uses_cards_when_none(self):
        scenes = [Scene("S01", "hook", "a " * 10), Scene("S02", "setup", "b " * 10)]
        clips = {"S01": [{"file": "x.mp4", "duration": 5}, {"file": "y.mp4", "duration": 5}], "S02": []}
        tl = assemble.build_timeline(scenes, 24.0, clips)
        self.assertEqual(tl[0]["start"], 0)
        self.assertAlmostEqual(tl[1]["start"], 12.0)
        self.assertEqual({s["clip"] for s in tl[0]["shots"]}, {"x.mp4", "y.mp4"})
        self.assertTrue(all(s["clip"] is None for s in tl[1]["shots"]))


@unittest.skipUnless(media.have_ffmpeg(), "ffmpeg not installed")
class RenderTests(unittest.TestCase):
    def test_real_render_matches_narration_length(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            clip = tmp / "c.mp4"
            make_test_clip(clip, 5)
            audio = tmp / "n.mp3"
            audio.write_bytes(FakeTTS().synthesize("word " * 40))  # 10 s
            total = media.duration(audio)
            scenes = [Scene("S01", "hook", "a " * 10), Scene("S02", "setup", "b " * 10)]
            tl = assemble.build_timeline(scenes, total, {"S01": [{"file": str(clip), "duration": 5}], "S02": []})
            out = assemble.render(tl, audio, tmp / "out.mp4", tmp / "work", size=(320, 180), fps=15)
            self.assertAlmostEqual(out["duration"], total, delta=1.0)
            self.assertEqual(out["shots"], sum(len(e["shots"]) for e in tl))
            self.assertTrue(Path(out["file"]).stat().st_size > 0)


class FinishingTests(unittest.TestCase):
    def test_captions_cover_each_scene_without_gaps(self):
        scenes = [Scene("S01", "hook", " ".join(f"w{i}" for i in range(20))), Scene("S02", "setup", "one two three")]
        tl = assemble.build_timeline(scenes, 30.0, {})
        cues = assemble.build_captions(scenes, tl, max_words=9)
        self.assertEqual(len(cues), 3 + 1)
        self.assertAlmostEqual(cues[0][0], 0.0)
        self.assertAlmostEqual(cues[-1][1], 30.0, places=2)
        for (a0, b0, _), (a1, _, _) in zip(cues, cues[1:]):
            self.assertAlmostEqual(b0, a1, places=2)
        with tempfile.TemporaryDirectory() as tmp:
            text = assemble.write_srt(cues, Path(tmp) / "c.srt").read_text()
            self.assertIn("00:00:00,000 --> ", text)
            self.assertTrue(text.startswith("1\n"))

    def test_shot_filter_pans_and_fades(self):
        f = assemble._shot_filter(3840, 2160, 4.0)
        self.assertIn("crop=3840:2160:x='(iw-3840)*t/4.000'", f)
        self.assertIn("fade=t=in", f)
        self.assertIn("fade=t=out:st=3.850", f)

    @unittest.skipUnless(media.have_ffmpeg(), "ffmpeg not installed")
    def test_render_with_music_and_burned_captions(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            clip = tmp / "c.mp4"
            make_test_clip(clip, 5)
            audio = tmp / "n.mp3"
            audio.write_bytes(FakeTTS().synthesize("word " * 40))
            music = tmp / "m.mp3"
            media.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=3", "-c:a", "libmp3lame", str(music)])
            total = media.duration(audio)
            scenes = [Scene("S01", "hook", "alpha beta gamma delta " * 3)]
            tl = assemble.build_timeline(scenes, total, {"S01": [{"file": str(clip), "duration": 5}]})
            srt = assemble.write_srt(assemble.build_captions(scenes, tl), tmp / "c.srt")
            out = assemble.render(tl, audio, tmp / "o.mp4", tmp / "w", size=(320, 180), fps=15, music=music, captions=srt, burn_captions=media.has_filter("subtitles"))
            self.assertTrue(out["music"])
            self.assertAlmostEqual(out["duration"], total, delta=1.0)


class AnalyticsTests(unittest.TestCase):
    base = {"ctr": 5.0, "retention": 40.0}

    def test_decision_tree(self):
        self.assertEqual(analytics.diagnose(6, 45, self.base)["verdict"], "make_more")
        self.assertEqual(analytics.diagnose(6, 30, self.base)["verdict"], "fix_content")
        self.assertEqual(analytics.diagnose(3, 45, self.base)["verdict"], "fix_packaging")
        self.assertEqual(analytics.diagnose(3, 30, self.base)["verdict"], "wrong_concept")
        self.assertEqual(analytics.diagnose(3, 30, None)["verdict"], "insufficient_baseline")

    def test_baseline_needs_three_videos_and_uses_median(self):
        self.assertIsNone(analytics.baseline_from([{"ctr": 1, "retention": 1}] * 2))
        b = analytics.baseline_from([{"ctr": 4, "retention": 30}, {"ctr": 8, "retention": 50}, {"ctr": 5, "retention": 40}])
        self.assertEqual((b["ctr"], b["retention"]), (5, 40))

    def test_retention_curve_finds_drop_and_rise_and_scene(self):
        with tempfile.TemporaryDirectory() as tmp:
            csv = Path(tmp) / "curve.csv"
            csv.write_text("time,percent\n0:00,100\n0:30,72\n2:00,65\n4:00,52\n6:00,39\n8:00,45\n10:00,34\n")
            points = analytics.parse_curve(csv)
        timeline = [
            {"scene": "S01", "section": "hook", "start": 0, "end": 60, "shots": []},
            {"scene": "S02", "section": "escalation", "start": 60, "end": 600, "shots": []},
        ]
        r = analytics.retention_insights(points, timeline)
        self.assertEqual(r["retention_30s"], 72)
        self.assertEqual(r["biggest_drop"]["from"], 0)  # 100 -> 72 is the steepest single step
        self.assertEqual(r["biggest_rise"]["from"], 360)
        self.assertEqual(r["biggest_rise"]["scene"], "S02")

    def test_parse_time(self):
        self.assertEqual(analytics.parse_time("1:30"), 90)
        self.assertEqual(analytics.parse_time("45"), 45)


if __name__ == "__main__":
    unittest.main()

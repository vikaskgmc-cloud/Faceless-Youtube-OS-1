import tempfile
import unittest
from pathlib import Path

from faceless_os import scoring
from faceless_os.llm import LLMError, extract_json
from faceless_os.models import Claim, Project
from faceless_os.pipeline import Pipeline
from faceless_os.storage import ProjectStore, StoreError
from faceless_os.workflow import GateError, advance, approve


class WorkflowTests(unittest.TestCase):
    def test_only_the_next_status_is_allowed(self):
        p = Project(id="x", topic="t")
        with self.assertRaises(GateError):
            advance(p, "RESEARCHING")  # skipping SELECTED

    def test_selected_needs_topic_approval(self):
        p = Project(id="x", topic="t")
        with self.assertRaises(GateError):
            advance(p, "SELECTED")
        approve(p, "topic")
        advance(p, "SELECTED")
        self.assertEqual(p.status, "SELECTED")
        self.assertEqual(p.history[-1]["to"], "SELECTED")

    def test_scripting_and_approved_and_upload_ready_need_approvals(self):
        for target, name in (("SCRIPTING", "research"), ("APPROVED", "script"), ("UPLOAD_READY", "thumbnail")):
            from faceless_os.models import STATUSES

            p = Project(id="x", topic="t", status=STATUSES[STATUSES.index(target) - 1])
            with self.assertRaises(GateError, msg=target):
                advance(p, target)
            approve(p, name)
            advance(p, target)
            self.assertEqual(p.status, target)


class ScoringTests(unittest.TestCase):
    def test_chatgpt_plan_example_scores_84(self):
        r = scoring.compute({"curiosity": 23, "audience": 19, "story": 19, "visuals": 9, "evergreen": 8, "monetization": 9, "difficulty": -3})
        self.assertEqual(r["total"], 84)
        self.assertTrue(r["passes"])
        self.assertEqual(r["max_possible"], 95)  # the formula tops out at 95, not 100

    def test_below_threshold_and_validation(self):
        r = scoring.compute({"curiosity": 10, "audience": 10, "story": 10, "visuals": 5, "evergreen": 5, "monetization": 5, "difficulty": 0})
        self.assertFalse(r["passes"])
        with self.assertRaises(scoring.ScoreError):
            scoring.compute({"curiosity": 26, "audience": 1, "story": 1, "visuals": 1, "evergreen": 1, "monetization": 1})
        with self.assertRaises(scoring.ScoreError):
            scoring.compute({"curiosity": 5})


class StorageTests(unittest.TestCase):
    def test_roundtrip_prefix_and_ids(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = ProjectStore(tmp)
            pipe = Pipeline(store)
            a = pipe.new_project("Why Costco is odd")
            b = pipe.new_project("Why Costco is odd")
            self.assertNotEqual(a.id, b.id)
            self.assertTrue(a.id.startswith("001-"))
            loaded = store.load("001")
            self.assertEqual(loaded.topic, "Why Costco is odd")
            loaded.set_claims([Claim(id="C001", claim="x", source_url="u", status="verified")])
            store.save(loaded)
            self.assertEqual(store.load(a.id).verified_claims()[0].id, "C001")
            with self.assertRaises(StoreError):
                store.load("999")

    def test_empty_topic_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(GateError):
                Pipeline(ProjectStore(tmp)).new_project("   ")


class JsonExtractTests(unittest.TestCase):
    def test_fences_and_prose(self):
        self.assertEqual(extract_json('```json\n{"a": 1}\n```'), {"a": 1})
        self.assertEqual(extract_json('Sure! Here you go: {"a": [1, 2]} hope it helps'), {"a": [1, 2]})
        with self.assertRaises(LLMError):
            extract_json("no json here")


if __name__ == "__main__":
    unittest.main()

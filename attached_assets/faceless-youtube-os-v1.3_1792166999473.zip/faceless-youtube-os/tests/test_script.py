import unittest

from faceless_os import factcheck, story, titles
from faceless_os.models import Claim, Project, Scene
from faceless_os.research import run_research
from tests.fakes import PAGES, ScriptedLLM, StaticSearch, base_llm_responses


def claims():
    return [
        Claim(id="C001", claim="Examplia had 9,000,000 vacant homes in 2023.", source_url="u", status="verified"),
        Claim(id="C002", claim="Owners pay property tax on empty homes every year.", source_url="u", status="verified"),
        Claim(id="C003", claim="A rumour says 50 homes were burnt.", source_url="u", status="needs_checking"),
    ]


class FactCheckTests(unittest.TestCase):
    def test_clean_script_passes(self):
        scenes = [
            Scene("S01", "hook", "Examplia had 9,000,000 vacant homes in 2023.", claim_ids=["C001"]),
            Scene("S02", "big_reveal", "Owners pay property tax on empty homes every year.", claim_ids=["C002"]),
            Scene("S03", "next_curiosity", "The next story is stranger."),
        ]
        r = factcheck.check_script(scenes, claims())
        self.assertTrue(r["ok"], r)
        self.assertEqual(r["stats"]["claims_used"], ["C001", "C002"])

    def test_number_without_source_blocks(self):
        scenes = [Scene("S01", "hook", "Almost 12,000,000 homes stand empty.", claim_ids=["C001"])]
        r = factcheck.check_script(scenes, claims())
        self.assertFalse(r["ok"])
        self.assertEqual(r["blocking"][0]["code"], "unsupported_number")

    def test_unverified_and_unknown_claims_block(self):
        scenes = [Scene("S01", "setup", "Something.", claim_ids=["C003", "C999"])]
        codes = {b["code"] for b in factcheck.check_script(scenes, claims())["blocking"]}
        self.assertEqual(codes, {"unverified_claim", "unknown_claim"})

    def test_small_numbers_are_not_flagged(self):
        scenes = [Scene("S01", "hook", "There are 3 reasons for this.", claim_ids=["C002"])]
        self.assertTrue(factcheck.check_script(scenes, claims())["ok"])

    def test_warnings_for_untagged_long_hook_begging_and_missing_sections(self):
        scenes = [
            Scene("S01", "hook", " ".join(["word"] * 60), claim_ids=["C002"]),
            Scene("S02", "discovery", "A fact with no tag."),
            Scene("S03", "next_curiosity", "Please subscribe and smash the bell."),
        ]
        r = factcheck.check_script(scenes, claims())
        codes = {w["code"] for w in r["warnings"]}
        self.assertTrue({"long_hook", "untagged_scene", "subscribe_begging", "missing_section"} <= codes)
        self.assertTrue(r["ok"])  # warnings never block

    def test_suspense_overuse_warns(self):
        scenes = [Scene("S01", "hook", "But there's a problem. " * 6, claim_ids=["C002"]), Scene("S02", "big_reveal", "x", claim_ids=["C002"]), Scene("S03", "next_curiosity", "y")]
        self.assertIn("suspense_overuse", {w["code"] for w in factcheck.check_script(scenes, claims())["warnings"]})

    def test_empty_script_blocks(self):
        self.assertFalse(factcheck.check_script([], claims())["ok"])


class StoryTests(unittest.TestCase):
    def make_project(self):
        p = Project(id="1", topic="Why Examplia has so many empty houses")
        run_research(p, ScriptedLLM(base_llm_responses()), StaticSearch(PAGES), results_per_question=6)
        return p

    def test_script_uses_only_verified_claims_and_passes_factcheck(self):
        p = self.make_project()
        llm = ScriptedLLM(base_llm_responses())
        scenes = story.generate_script(p, llm)
        verified = {c.id for c in p.verified_claims()}
        for s in scenes:
            self.assertTrue(set(s.claim_ids) <= verified)
        self.assertEqual([s.section for s in scenes][0], "hook")
        self.assertEqual(scenes[-1].section, "next_curiosity")
        self.assertTrue(factcheck.check_script(scenes, p.claims())["ok"])
        self.assertEqual([s.id for s in scenes], [f"S{i:02d}" for i in range(1, len(scenes) + 1)])

    def test_series_and_next_video_reach_the_script_writer(self):
        p = self.make_project()
        p.series, p.next_idea = "Quiet Giants", "The city that paid people to stay"
        seen = {}

        def capture(payload):
            seen.update(payload)
            return {"scenes": [{"section": "hook", "narration": "x", "claim_ids": []}]}

        story.generate_script(p, ScriptedLLM({"write_script": capture}))
        self.assertEqual((seen["series"], seen["next_video"]), ("Quiet Giants", "The city that paid people to stay"))

    def test_scenes_are_put_in_story_order(self):
        p = self.make_project()
        order = {"scenes": [
            {"section": "next_curiosity", "narration": "end", "claim_ids": []},
            {"section": "hook", "narration": "start", "claim_ids": []},
        ]}
        scenes = story.generate_script(p, ScriptedLLM({"write_script": order}))
        self.assertEqual([s.section for s in scenes], ["hook", "next_curiosity"])

    def test_refuses_without_enough_verified_claims(self):
        p = Project(id="2", topic="t")
        p.set_claims([Claim(id="C001", claim="a", source_url="u", status="verified")])
        with self.assertRaises(story.ScriptError):
            story.generate_script(p, ScriptedLLM(base_llm_responses()))

    def test_bad_model_output_rejected(self):
        p = self.make_project()
        with self.assertRaises(story.ScriptError):
            story.generate_script(p, ScriptedLLM({"write_script": {"scenes": [{"section": "nonsense", "narration": "x"}]}}))

    def test_narration_text_has_only_spoken_words(self):
        scenes = [Scene("S01", "hook", "Hello."), Scene("S02", "setup", "World.")]
        self.assertEqual(story.narration_text(scenes), "Hello.\n\nWorld.")
        self.assertIn("## HOOK", story.script_text(scenes))


class TitleTests(unittest.TestCase):
    def test_title_checks(self):
        allowed = {"9000000"}
        self.assertEqual(titles.check_title("Why Nobody Can Sell These Homes", allowed), [])
        self.assertEqual(titles.check_title("9,000,000 Empty Homes", allowed), [])
        bad = titles.check_title("12,000,000 Empty Homes", allowed)
        self.assertEqual(bad[0]["level"], "blocking")
        self.assertTrue(titles.check_title("A" * 80, allowed))
        self.assertTrue(titles.check_title("WHY IS EVERYTHING SHOUTING", allowed))
        self.assertEqual(titles.check_title("", allowed)[0]["level"], "blocking")

    def test_thumbnail_words(self):
        self.assertEqual(titles.check_thumbnail_words("NOT FREE"), [])
        self.assertTrue(titles.check_thumbnail_words("ONE TWO THREE FOUR FIVE"))
        self.assertTrue(titles.check_thumbnail_words(""))


if __name__ == "__main__":
    unittest.main()

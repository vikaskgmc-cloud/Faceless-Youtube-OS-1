import unittest

from faceless_os.models import Claim, Project
from faceless_os.research import ResearchError, mark_conflicts, normalize, numbers_in, run_research, verify_claim
from tests.fakes import PAGES, ScriptedLLM, StaticSearch, base_llm_responses


class VerifyTests(unittest.TestCase):
    page = "The 2023 survey counted 9,000,000 vacant homes in Examplia. That is 14% of all housing."

    def test_exact_quote_and_numbers_verify(self):
        status, by, _ = verify_claim("Examplia had 9,000,000 vacant homes in 2023.", "The 2023 survey counted 9,000,000 vacant homes in Examplia.", self.page)
        self.assertEqual((status, by), ("verified", "quote-match"))

    def test_quote_must_appear_in_page(self):
        status, _, note = verify_claim("Whatever.", "This quote is not on the page whatsoever.", self.page)
        self.assertEqual(status, "needs_checking")
        self.assertIn("not found", note)

    def test_short_quote_rejected(self):
        self.assertEqual(verify_claim("14%", "14% of all", self.page)[0], "needs_checking")

    def test_numbers_in_claim_must_be_in_quote(self):
        status, _, note = verify_claim("There were 10,000,000 vacant homes.", "The 2023 survey counted 9,000,000 vacant homes in Examplia.", self.page)
        self.assertEqual(status, "needs_checking")
        self.assertIn("10000000", note)

    def test_normalisation_handles_quotes_markdown_and_whitespace(self):
        page = "He said “it’s **big**”  and\n[more](http://x) followed."
        self.assertIn(normalize('he said "it\'s big" and more followed'), normalize(page))

    def test_meaning_changing_words_must_be_in_the_quote(self):
        quote = "The 2023 survey counted 9 million vacant homes in Examplia."
        page = quote + " More text."
        self.assertEqual(verify_claim("Examplia has 9 million vacant homes.", quote, page)[0], "verified")
        status, _, note = verify_claim("Examplia has 9 billion vacant homes.", quote, page)
        self.assertEqual(status, "needs_checking")
        self.assertIn("billion", note)
        self.assertEqual(verify_claim("Most of the 9 million homes are empty.", quote, page)[0], "needs_checking")

    def test_numbers_in(self):
        self.assertEqual(numbers_in("9,000,000 homes, 14% and 3.5 times in 1998"), {"9000000", "14", "3.5", "1998"})


class ConflictTests(unittest.TestCase):
    def test_same_metric_different_numbers_conflict(self):
        a = Claim(id="C001", claim="9,000,000 homes", source_url="a", status="verified", metric="homes 2023")
        b = Claim(id="C002", claim="8,500,000 homes", source_url="b", status="verified", metric="homes 2023")
        c = Claim(id="C003", claim="14% of housing", source_url="a", status="verified", metric="")
        mark_conflicts([a, b, c])
        self.assertEqual([a.status, b.status, c.status], ["conflicting", "conflicting", "verified"])

    def test_same_numbers_do_not_conflict(self):
        a = Claim(id="C001", claim="9,000,000 homes", source_url="a", status="verified", metric="homes 2023")
        b = Claim(id="C002", claim="There are 9,000,000 homes", source_url="b", status="verified", metric="homes 2023")
        mark_conflicts([a, b])
        self.assertEqual([a.status, b.status], ["verified", "verified"])


class RunResearchTests(unittest.TestCase):
    def setUp(self):
        self.project = Project(id="001-x", topic="Why Examplia has so many empty houses", pillar="countries")
        self.llm = ScriptedLLM(base_llm_responses())
        run_research(self.project, self.llm, StaticSearch(PAGES), today="2026-10-16", results_per_question=6)
        self.by_text = {c.claim: c for c in self.project.claims()}

    def test_only_quote_backed_claims_are_verified(self):
        self.assertEqual(self.by_text["Examplia had 9,000,000 vacant homes in 2023."].status, "conflicting")  # the rival study disagrees
        self.assertEqual(self.by_text["Vacant homes are 14% of all housing in Examplia."].status, "verified")
        self.assertEqual(self.by_text["Owners love empty houses."].status, "needs_checking")  # fabricated quote
        self.assertEqual(self.by_text["Demolition costs 30,000 credits on average."].status, "needs_checking")  # changed number
        self.assertEqual(self.by_text["The number of vacant homes has tripled since 1998."].status, "needs_checking")  # 'doubled' became 'tripled'

    def test_invented_source_index_is_dropped(self):
        self.assertNotIn("Invented source.", self.by_text)

    def test_conflict_between_sources_is_flagged_on_both(self):
        self.assertEqual(self.by_text["A private study counted 8,500,000 vacant homes in 2023."].status, "conflicting")

    def test_records_dates_sources_and_unverified_list(self):
        claim = self.by_text["Vacant homes are 14% of all housing in Examplia."]
        self.assertEqual(claim.checked_on, "2026-10-16")
        self.assertEqual(claim.source_url, "https://example.org/stats")
        summary = self.project.research["summary"]
        self.assertTrue(summary["draft"])
        self.assertIn(self.by_text["Owners love empty houses."].id, summary["unverified_claim_ids"])
        self.assertEqual(len(self.project.research["sources"]), len(PAGES))

    def test_ids_are_sequential(self):
        ids = [c.id for c in self.project.claims()]
        self.assertEqual(ids, [f"C{i:03d}" for i in range(1, len(ids) + 1)])

    def test_search_failures_are_recorded_not_fatal(self):
        class Flaky(StaticSearch):
            def search(self, query, limit=4):
                if "empty" in query:
                    raise RuntimeError("network down")
                return super().search(query, limit)

        p = Project(id="2", topic="t")
        run_research(p, ScriptedLLM(base_llm_responses()), Flaky(PAGES))
        self.assertTrue(any("network down" in e["error"] for e in p.research["errors"]))
        self.assertTrue(p.claims())

    def test_no_claims_at_all_raises(self):
        with self.assertRaises(ResearchError):
            run_research(Project(id="3", topic="t"), ScriptedLLM(base_llm_responses()), StaticSearch([]))


if __name__ == "__main__":
    unittest.main()
